#smugglers island  larg
#!/usr/bin/env python

import random, pygame, sys, time
from pygame.locals import*

FPS = 30   ##15
WINDOWWIDTH = 1300   ##width
WINDOWHEIGHT = 900   ##height
#             R    G    B    
WHITE     = (255, 255, 255)
BLACK     = (  0,   0,   0)
RED       = (255,   0,   0)
GREEN     = (  0, 255,   0)
DARKGREEN = (  0, 155,   0)
DARKGRAY  = ( 40,  40,  40)
YELLOW    = (255, 255,   0)
PPUPLE    = (255, 209, 255)
PBLUE     = (156, 255, 255)
PYELLOW   = (255, 255, 169)
BLUE      = (  0,   0, 255)
BGCOLOR = BLACK

pygame.init()
score=0
tres=0
Doors=0
trys=0

FPSCLOCK = pygame.time.Clock()
pygame.display.set_icon(pygame.image.load('eyesaa.png')) 
DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
BASICFONT = pygame.font.Font('freesansbold.ttf', 18)
BIGFONT=pygame.font.Font('freesansbold.ttf', 36)
pygame.display.set_caption('**SMUGGLERS ISLAND**')
titleFont = pygame.font.Font('freesansbold.ttf', 100)
PICa_SURF=pygame.image.load('sea_shoreaaa.png').convert()
PICb_SURF=pygame.image.load('sea_shorebbb.png').convert()
PICd_SURF=pygame.image.load('sea_shoreccc.png').convert()
PICe_SURF=pygame.image.load('sea_shoreb22.png').convert()
islPicA_SURF=pygame.image.load('islandScreen22.png').convert()
islPicB_SURF=pygame.image.load('islandTideOut.png').convert()
bChair_SURF=pygame.image.load('beachChair.png').convert()
grayStone_SURF=pygame.image.load('greyStone.png').convert()
blueStone_SURF=pygame.image.load('blueStone.png').convert()
underCpic_SURF=pygame.image.load('underSeaSeen.png').convert()
fishimg=pygame.image.load('fish.png').convert
cave1_SURF =pygame.image.load('cave1aa.png').convert()
cave2_SURF=pygame.image.load('cave2.png').convert()
redStone_SURF=pygame.image.load('redStone.png').convert()
rope_SURF=pygame.image.load('rope.png').convert()
key_SURF=pygame.image.load('key.png').convert()
eye_SURF=pygame.image.load('eyesaa.png').convert()
chesta_SURF=pygame.image.load('cest1a.png').convert()
chestb_SURF=pygame.image.load('cest2b.png').convert()
caveFallRope_SURF=pygame.image.load('caveFallRope.png').convert()
bTunn_SURF=pygame.image.load('blueTunnel123.png').convert()
ted2Side_SURF=pygame.image.load('ted2side.png').convert()
ted2Fall_SURF=pygame.image.load('ted2Fall.png').convert()
tedRope_SURF=pygame.image.load('tedRope.png').convert()
ted2Front_SURF=pygame.image.load('ted2front.png').convert()
caveFall_SURF=pygame.image.load('caveFall.png').convert()
mCat_SURF=pygame.image.load('MerCatSmall.png').convert()
tedBackS_SURF=pygame.image.load('tedBackS.png').convert()
tunnel_SURF=pygame.image.load('tunnel.png').convert()
greenS_SURF=pygame.image.load('greenStone.png').convert()
torch_SURF=pygame.image.load('torch.png').convert()
feather_SURF=pygame.image.load('feather.png').convert()
fairyA_SURF=pygame.image.load('sfairya.png').convert()
battery_SURF=pygame.image.load('battery.png').convert()
note_SURF=pygame.image.load('noteBatts.png').convert()
noteS_SURF=pygame.image.load('notestart.png').convert()
tres_SURF=pygame.image.load('tres.png').convert()
tunHole_SURF=pygame.image.load('tunnelHole.png').convert()
waterCave_SURF=pygame.image.load('waterCave.png').convert()
glitBall_SURF=pygame.image.load('gliterBall.png').convert()
fin_SURF=pygame.image.load('fishFin.png').convert()
L_FIN_IMG=pygame.image.load('fishFin.png')
R_FIN_IMG=pygame.transform.flip(L_FIN_IMG, True, False)
hat_SURF=pygame.image.load('hat.png').convert()
wetTed_SURF=pygame.image.load('wetTed.png').convert()
madFish_SURF=pygame.image.load('madFish.png').convert()
ted2FallR_IMG=pygame.transform.flip(ted2Fall_SURF, True, False)
halfTed_SURF=pygame.image.load('halfTed.png').convert()
lottie_SURF=pygame.image.load('lottie.png').convert()
tunLR_SURF=pygame.image.load('tunL_R.png').convert()
redTunXY_SURF=pygame.image.load('redTunnelxy.png').convert()
cBar_SURF=pygame.image.load('cBar.png').convert()
candy_SURF=pygame.image.load('candy.png').convert()
blueDoor_SURF=pygame.image.load('blueDoor.png').convert()
redDoor_SURF=pygame.image.load('redDoor.png').convert()
mineShaft_SURF=pygame.image.load('mineShaft.png').convert()
catBall_SURF=pygame.image.load('catBall.png').convert()
B_R_ticket_SURF=pygame.image.load('B_R_ticket.png').convert()
busTicket_SURF=pygame.image.load('bussTicket.png').convert()
railTicket_SURF=pygame.image.load('railTicket.png').convert()
Mouse_SURF=pygame.image.load('catsMouse.png').convert()
sockPuzB_SURF=pygame.image.load('sockPuzB.png').convert()
keyPuzE_SURF=pygame.image.load('keyPuzE.png').convert()
tilePuzE_SURF=pygame.image.load('tilePuzE.png').convert()
mushPuz_SURF=pygame.image.load('mushroomPuz.png').convert()
tedFloat_IMG=pygame.transform.flip(ted2Fall_SURF, False, True)
jugsPuzF_SURF=pygame.image.load('jugsPuzF.png').convert()
butFlyB_SURF=pygame.image.load('butFlyB.png').convert()
candPapper_SURF=pygame.image.load('candPapper.png').convert()
trainEnd_SURF=pygame.image.load('trainEnd.png').convert()
railTun_SURF=pygame.image.load('railway.png').convert()
carageTun_SURF = pygame.image.load('carage_tunnel.png').convert()
tunFill_SURF = pygame.image.load('carage_tunnelfill.png').convert()
carage_SURF = pygame.image.load('carage.png').convert()
tresChest_SURF=pygame.image.load('tresChestAA.png').convert()
tresCave_SURF=pygame.image.load('tresCaveA.png').convert()
candleA_SURF=pygame.image.load('candleAA.png').convert()
candleB_SURF=pygame.image.load('candleBB.png').convert()
mouseCave =pygame.image.load('mouseCaveALarg.png').convert()
bookOpen=pygame.image.load('blBokOpen.png').convert()

candle1A_SURF=pygame.image.load('candle11.png').convert()
candle1B_SURF=pygame.image.load('candle22.png').convert()
booz_SURF=pygame.image.load('boozPic.png').convert()
barrelPuzS=pygame.image.load('barrelPuzSS.png').convert()
barrelPuz=pygame.image.load('barrolPuz.png').convert()
barrelPuzA=pygame.image.load('barrolPuzAA.png').convert()
barrelPuzB=pygame.image.load('barrolPuzBB.png').convert()
barrelPuzC=pygame.image.load('barrolPuzCC.png').convert()
ring=pygame.image.load('ring.png').convert()
flash=pygame.image.load('starFlash.png').convert()
bela=pygame.image.load('bela.png').convert()
blacka = pygame.image.load('blacka.png').convert()

soundObj = pygame.mixer.Sound('batFlapL.wav')
oceanObj = pygame.mixer.Sound('oceanWaves.wav')
seaWavesObj = pygame.mixer.Sound('seawaves.wav')
trainObj = pygame.mixer.Sound('steamtrain.wav')
drumObj = pygame.mixer.Sound('drumrollLong2.wav')
gullsObj=pygame.mixer.Sound('gulls.wav')
windObj=pygame.mixer.Sound('cavewinds.wav')
thumpObj=pygame.mixer.Sound('thump.wav')
honkObj=pygame.mixer.Sound('toyHonk22.wav')
underSeaObj=pygame.mixer.Sound('unSeaBubles.wav')
doorObj=pygame.mixer.Sound('barndoor.wav')
mousesObj=pygame.mixer.Sound('mouses.wav')
woodCObj=pygame.mixer.Sound('woodCrack.wav')

                             
def main():
    startAn()
    global score
    global tres
    global Doors
    score = 0
    tres = 0
    Doors = 0
    while True:
        runGame()        
    pygame.display.update()
    
def finnish():
    pygame.quit()
    sys.exit()
def checkForQuit():
    for event in pygame.event.get(QUIT): 
        finnish()
    for event in pygame.event.get(KEYUP):
        if event.key == K_ESCAPE:
            finnish()
        pygame.event.post(event)
          
def startAn():
    oceanObj.play()
    gullsObj.play()
    DISPLAYSURF.fill(BLACK)
    startKeyMes()
    while True:
        nameSurf=BASICFONT.render("** By Tho's Tibbetts **", True, RED)
        nameRect=nameSurf.get_rect()
        nameRect.midtop=(WINDOWWIDTH /2, 700)
        DISPLAYSURF.blit(nameSurf, nameRect)    
        DISPLAYSURF.blit(PICa_SURF, (350, 5))
        titleSurf=titleFont.render("**SMUGGLERS  ISLAND**", True, GREEN)
        titleRect=titleSurf.get_rect()
        titleRect.midtop=(WINDOWWIDTH /2, 500)
        DISPLAYSURF.blit(titleSurf, titleRect)
        pygame.time.wait(200)
        pygame.display.update()    
        DISPLAYSURF.blit(PICb_SURF, (350, 5))
        titleSurf=titleFont.render("**SMUGGLERS  ISLAND**", True, YELLOW)
        titleRect=titleSurf.get_rect()
        titleRect.midtop=(WINDOWWIDTH /2, 500)
        DISPLAYSURF.blit(titleSurf, titleRect)
        pygame.time.wait(200)
        pygame.display.update()    
        DISPLAYSURF.blit(PICd_SURF, (350, 5))
        titleSurf=titleFont.render("**SMUGGLERS  ISLAND**", True, BLUE)
        titleRect=titleSurf.get_rect()
        titleRect.midtop=(WINDOWWIDTH /2, 500)
        DISPLAYSURF.blit(titleSurf, titleRect)
        pygame.time.wait(200)
        pygame.display.update()    
        DISPLAYSURF.blit(PICe_SURF, (350, 5))
        titleSurf=titleFont.render("**SMUGGLERS  ISLAND**", True, RED)
        titleRect=titleSurf.get_rect()
        titleRect.midtop=(WINDOWWIDTH /2, 500)
        DISPLAYSURF.blit(titleSurf, titleRect)
        pygame.time.wait(200)
        pygame.display.update()    
        DISPLAYSURF.blit(PICb_SURF, (350, 5))    
        titleSurf=titleFont.render("**SMUGGLERS  ISLAND**", True, RED)
        titleRect=titleSurf.get_rect()
        titleRect.midtop=(WINDOWWIDTH /2, 500)
        DISPLAYSURF.blit(titleSurf, titleRect)
        if keyPress():
            
            pygame.event.get()
            pygame.mixer.Sound.stop(oceanObj)
            pygame.mixer.Sound.stop(gullsObj)            
            #tunnelYchest() ## function tests     # ?????()
            return  ##back to top of loop
        
        pygame.time.wait(500)
        pygame.display.update()
        FPSCLOCK.tick(FPS) 

def keyPress():##press any key to continue
    if len(pygame.event.get(QUIT)) > 0:
        finnish()
    keyUpEvents= pygame.event.get(KEYUP)
    if len(keyUpEvents) == 0:
        return None
    if keyUpEvents[0].key == K_ESCAPE:
        finnish()
    return keyUpEvents[0].key

def startKeyMes():
    startKeyFont=pygame.font.Font('freesansbold.ttf', 70)
    startKeySurf=startKeyFont.render('*Press a key to continue*', True, BLUE)
    startKeyRect = startKeySurf.get_rect()
    startKeyRect.midtop =(WINDOWWIDTH /2, 800)
    DISPLAYSURF.blit(startKeySurf, startKeyRect)
def pleaseWait():
    waitKeyFont=pygame.font.Font('freesansbold.ttf', 70)
    waitKeySurf=waitKeyFont.render('*Please  Wait*', True, BLUE)
    waitKeyRect = waitKeySurf.get_rect()
    waitKeyRect.midtop =(WINDOWWIDTH /2, 800)
    DISPLAYSURF.blit(waitKeySurf, waitKeyRect)

def gameOver():##back to start
    while True:
        DISPLAYSURF.fill(BLACK)
        gameOverFont = pygame.font.Font('freesansbold.ttf', 90)
        gameSurf = gameOverFont.render('* GAME OVER *', True, RED)
        gameRect = gameSurf.get_rect()
        gameRect.midtop = (WINDOWWIDTH /2, 590)
        DISPLAYSURF.blit(gameSurf, gameRect)
        startKeyMes()
        if keyPress():
            pygame.event.get()
            return main()
        pygame.time.wait(500)   
        pygame.display.update()
        FPSCLOCK.tick(FPS)
    
def flip():
    global backDrop_SURF, degrees
    flip1_SURF=pygame.image.load('tedFlip1_4.png').convert()
    flip2_SURF=pygame.image.load('tedFlip2.png').convert()
    flip3_SURF=pygame.image.load('tedFlip3.png').convert()
    flip5_SURF=pygame.image.load('tedFlip5.png').convert()
    flip6_SURF=pygame.image.load('tedFlip6.png').convert()        
    backDrop_SURF=pygame.image.load('tunnel.png').convert()
    degrees = 0

    DISPLAYSURF.blit(backDrop_SURF, (5, 5))
    DISPLAYSURF.blit(flip5_SURF, (590, 400))
    pygame.display.update()
    pygame.time.wait(1000)
    DISPLAYSURF.blit(backDrop_SURF, (5, 5))       
    DISPLAYSURF.blit(flip1_SURF, (500, 400))
    pygame.display.update()
    pygame.time.wait(200)
    DISPLAYSURF.blit(backDrop_SURF, (5, 5))       
    DISPLAYSURF.blit(flip1_SURF, (500, 340))
    pygame.display.update()
    pygame.time.wait(200)
    DISPLAYSURF.blit(backDrop_SURF, (5, 5))       
    DISPLAYSURF.blit(flip2_SURF, (500, 320))
    pygame.display.update()
    pygame.time.wait(200)
    
    while True:
        drumObj.play()
        
        DISPLAYSURF.blit(backDrop_SURF, (5, 5))        
        DISPLAYSURF.blit(flip5_SURF, (590, 310))
        DISPLAYSURF.blit(backDrop_SURF, (5, 5))              
        rotatedSurf1 = pygame.transform.rotate(flip3_SURF, degrees)
        rotatedRect1 = rotatedSurf1.get_rect()
        rotatedRect1.center = (WINDOWWIDTH / 2, WINDOWHEIGHT / 2)
        DISPLAYSURF.blit(rotatedSurf1, rotatedRect1)
        pygame.display.update()
        degrees += 8
        
        if degrees >= 600:
            DISPLAYSURF.blit(backDrop_SURF, (5, 5))               
            DISPLAYSURF.blit(flip2_SURF, (500, 310))
            pygame.display.update()
            pygame.time.wait(200)            
            DISPLAYSURF.blit(backDrop_SURF, (5, 5))               
            DISPLAYSURF.blit(flip1_SURF, (500, 320))
            pygame.display.update()
            pygame.time.wait(200)
            DISPLAYSURF.blit(backDrop_SURF, (5, 5))               
            DISPLAYSURF.blit(flip1_SURF, (500, 340))
            pygame.display.update()
            pygame.time.wait(200)                
            DISPLAYSURF.blit(backDrop_SURF, (5, 5))                    
            DISPLAYSURF.blit(flip5_SURF, (590, 360))
            pygame.display.update()
            pygame.time.wait(300)            
            DISPLAYSURF.blit(backDrop_SURF, (5, 5))                
            DISPLAYSURF.blit(flip6_SURF, (500, 360))
            pygame.display.update()
            pygame.mixer.Sound.stop(drumObj)             
            pygame.time.wait(4000)
            break
            return
    checkForQuit()        
    FPSCLOCK.tick(FPS)##ok

def batFly():  ##left ot right
    soundObj.play()      
    width = 130  # size of bat
    height = 130    
    fly1x=10
    fly1y=160
    fly2x=20  
    fly2y=160
    fly3x=30
    fly3y=160

    direction='right'
    while True:    
        if direction=='right':    
            fly1x += 15    
            width -= 2 # decrease the size of bat
            height -= 2            
            
            DISPLAYSURF.blit(patch_SURF, (5, 5))
            bat1 = pygame.transform.scale(fly1img, (width, height))            
            DISPLAYSURF.blit(bat1, (fly1x, fly1y))            
            DISPLAYSURF.blit(halfDrop_SURF, (5, 5))
            pygame.display.update()            
            pygame.time.wait(50)             
            fly2x = fly1x 
                       
            fly2x += 15
            width -= 2  # decrease the size of bat
            height -=2        
            DISPLAYSURF.blit(patch_SURF, (5, 5))
            bat2 = pygame.transform.scale(fly2img, (width, height))            
            DISPLAYSURF.blit(bat2, (fly2x, fly2y))       
            DISPLAYSURF.blit(halfDrop_SURF, (5, 5))
            pygame.display.update()             
            pygame.time.wait(50)                  
            fly3x = fly2x
                
            fly3x += 15
            width -= 2  # decrease the size of bat
            height -=2        
            DISPLAYSURF.blit(patch_SURF, (5, 5))
            bat3 = pygame.transform.scale(fly2img, (width, height))            
            DISPLAYSURF.blit(bat3, (fly3x, fly3y))       
            DISPLAYSURF.blit(halfDrop_SURF, (5, 5))
            pygame.display.update()             
            pygame.time.wait(50)          
            fly1x = fly3x 
                            
            checkForQuit()
                               
            if fly1x >= 900:
                pygame.mixer.Sound.stop(soundObj)                  
                pygame.time.wait(3000)
                break
                return
            if fly2x >= 900:
                pygame.mixer.Sound.stop(soundObj)                  
                pygame.time.wait(3000)
                break
                return# sent back to program
            if fly3x >= 900:
                pygame.mixer.Sound.stop(soundObj)                  
                pygame.time.wait(3000)
                break
                return                            
        
    FPSCLOCK.tick(FPS)##ok
        
def blueStone():
    underSeaObj.play()
    startTime = 0
    startTime = time.time()    
    global score
    score += 5
    while True:
        DISPLAYSURF.fill(BLACK)        
        DISPLAYSURF.blit(underCpic_SURF,(5, 5))
        DISPLAYSURF.blit(blueStone_SURF, (600, 620))
        DISPLAYSURF.blit(ted2Side_SURF, (500, 300))
        bStoneFont=pygame.font.Font('freesansbold.ttf', 24)
        bStoneSurf=bStoneFont.render(
'You picked the heavy blue stone.Ted fall into the sea and sank like a stone ,the water is not very deep', True, YELLOW)
        bStoneRect=bStoneSurf.get_rect()
        bStoneRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(bStoneSurf, bStoneRect)
        
        bStone2Font=pygame.font.Font('freesansbold.ttf', 20)
        bStone2Surf=bStone2Font.render(
'there is a submerged sea wall that runs up to the island ,Ted climbs onto the wall.The sea is only up to his knees. ', True, YELLOW)
        bStone2Rect=bStone2Surf.get_rect()
        bStone2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(bStone2Surf, bStone2Rect)        
        bStone3Font=pygame.font.Font('freesansbold.ttf', 24)
        bStone3Surf=bStone3Font.render(
'The tide is going out and the wall is soon above the sea and Ted can walk to smugglers island.', True, YELLOW)
        bStone3Rect=bStone3Surf.get_rect()
        bStone3Rect.midtop=(WINDOWWIDTH/2, 790)
        DISPLAYSURF.blit(bStone3Surf, bStone3Rect)
        startKeyMes()
        if time.time() - 60 > startTime:
            fish()#ok             
        if keyPress():
            pygame.event.get()
            fish()
       
        pygame.display.update()
        FPSCLOCK.tick(FPS)
        
         
def fish():
    fishimg=pygame.image.load('fish.png')
    fishx=300
    fishy=10
    direction='right'
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(underCpic_SURF, (5, 5))
        pleaseWait()
        if direction=='right':
            fishx+=5
            if fishx==1400:
                pygame.time.wait(500)##ok
                pygame.mixer.Sound.stop(underSeaObj)                
                caveOneB()   
        DISPLAYSURF.blit(fishimg, (fishx, fishy))
        pygame.display.update()
        FPSCLOCK.tick(FPS)##ok

def grayStone():
    underSeaObj.play()
    startTime = 0
    startTime = time.time()
    global score
    score += 5
    while True:
        DISPLAYSURF.fill(BLACK)        
        DISPLAYSURF.blit(underCpic_SURF, (5, 5))
        DISPLAYSURF.blit(grayStone_SURF, (600, 620))
        DISPLAYSURF.blit(ted2Side_SURF, (550, -100))
        
        gStoneFont=pygame.font.Font('freesansbold.ttf', 24)
        gStoneSurf=gStoneFont.render(
'Ted jumps in the sea holding tight to his gray stone it keeps him afloat ,as he trys to swim to the island', True, YELLOW)        
        gStoneRect=gStoneSurf.get_rect()
        gStoneRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(gStoneSurf, gStoneRect)
        bStone2Font=pygame.font.Font('freesansbold.ttf', 20)
        bStone2Surf=bStone2Font.render(
'there is a submerged sea wall that runs upto the island ,Ted climbs onto the wall.The sea is only up to his knees. ', True, YELLOW)
        bStone2Rect=bStone2Surf.get_rect()
        bStone2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(bStone2Surf, bStone2Rect)        
        bStone3Font=pygame.font.Font('freesansbold.ttf', 24)
        bStone3Surf=bStone3Font.render(
'The tide is going out and the wall is soon above the sea and Ted can walk to smugglers island.', True, YELLOW)
        bStone3Rect=bStone3Surf.get_rect()
        bStone3Rect.midtop=(WINDOWWIDTH/2, 790)
        DISPLAYSURF.blit(bStone3Surf, bStone3Rect)        
        startKeyMes()
        if time.time() - 60 > startTime:
            fish()#ok        
        if keyPress():
            pygame.event.get()
            fish()
        pygame.display.update()
        FPSCLOCK.tick(FPS)##ok
def chair():##sea shore
    oceanObj.play()
    DISPLAYSURF.fill(BLACK)
    global score
    score +=10
    while True:
        DISPLAYSURF.blit(islPicB_SURF, (5, 15))
        DISPLAYSURF.blit(bChair_SURF, (600, 620))
        DISPLAYSURF.blit(tedBackS_SURF, (1200, 200))
        
        bChairFont=pygame.font.Font('freesansbold.ttf', 24)
        bChairSurf=bChairFont.render(
'Sitting in his chair watching the tide go out Ted noticed the beach is getting closer to the island', True, YELLOW)        
        bChairRect=bChairSurf.get_rect()
        bChairRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(bChairSurf, bChairRect)
        
        bChair2Font=pygame.font.Font('freesansbold.ttf', 24)        
        bChair2Surf=bChair2Font.render(
"At low tide the beach joins the islands beach,it's only a 15 mins walk to Smuggler Island.", True, YELLOW)
        bChair2Rect=bChair2Surf.get_rect()
        bChair2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(bChair2Surf, bChair2Rect)
        startKeyMes()              
        if keyPress():
            pygame.event.get()
            pygame.mixer.Sound.stop(oceanObj)             
            caveOne()          
        pygame.display.update()

def caveOne():#total score
    DISPLAYSURF.fill(BLACK)    
    while True:
        DISPLAYSURF.blit(cave1_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF, (400, 300))
        cave1Font=pygame.font.Font('freesansbold.ttf', 24)        
        cave1Surf=cave1Font.render(
"Ted reached the island and did not get wet.Score 10 out of 10 ,In the side of the hill is a dark cave.  ", True, YELLOW)
        cave1Rect=cave1Surf.get_rect()
        cave1Rect.midtop=(WINDOWWIDTH/2, 720)
        DISPLAYSURF.blit(cave1Surf, cave1Rect)
        
        cave2Font=pygame.font.Font('freesansbold.ttf', 24)        
        cave2Surf=cave2Font.render(
"  Top score.  Press,  e  ,to enter the cave.", True, YELLOW)
        cave2Rect=cave2Surf.get_rect()
        cave2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(cave2Surf, cave2Rect)

        scoSurf=BIGFONT.render('Score:' + str(score), 1, RED)
        scoRect=scoSurf.get_rect()
        scoRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoSurf, scoRect)

        trSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)
        trRect=trSurf.get_rect()
        trRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(trSurf, trRect)
        
        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_e):
                    caveTwo()                    
        pygame.display.update()
                        
def caveOneB():#total score
    DISPLAYSURF.fill(BLACK)    
    while True:
        DISPLAYSURF.blit(cave1_SURF, (5, 5))
        DISPLAYSURF.blit(wetTed_SURF, (200, 300))
        cave1Font=pygame.font.Font('freesansbold.ttf', 24)        
        cave1Surf=cave1Font.render(
"Ted reached the island very wet, 5 out of 10 for effort.When Teds dry he can enter the cave in the side of the hill.", True, YELLOW)
        cave1Rect=cave1Surf.get_rect()
        cave1Rect.midtop=(WINDOWWIDTH/2, 720)
        DISPLAYSURF.blit(cave1Surf, cave1Rect)
        
        cave2Font=pygame.font.Font('freesansbold.ttf', 24)        
        cave2Surf=cave2Font.render(
"** You  nearly  drowned  Ted.     Press  ,  e  , to enter the cave **.", True, YELLOW)
        cave2Rect=cave2Surf.get_rect()
        cave2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(cave2Surf, cave2Rect)
        
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)

        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect) 
        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_e):
                    caveTwo()
        pygame.display.update()                
                              
def runGame():
    DISPLAYSURF.fill(BLACK)
    pygame.display.update()
    cShore()
    
def cShore():##start
    oceanObj.play()
    DISPLAYSURF.fill(BLACK)    
    while True:       
        DISPLAYSURF.blit(islPicA_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF, (5, 600))
        DISPLAYSURF.blit(bChair_SURF, (350, 620))
        DISPLAYSURF.blit(grayStone_SURF, (530, 620))
        DISPLAYSURF.blit(blueStone_SURF, (730, 620))

        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)###ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)

        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)###ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)
        
        cShoreFont=pygame.font.Font('freesansbold.ttf', 18)
        cShoreSurf=cShoreFont.render(
'Goal,  **  Get Ted to the island //   One of the items may get him there safely.   You may only pick one item.',True, YELLOW)
        cShoreRect=cShoreSurf.get_rect()
        cShoreRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(cShoreSurf, cShoreRect)
    
        cShore2Font=pygame.font.Font('freesansbold.ttf', 18)
        cShore2Surf=cShore2Font.render(
'Items, *  (a) Beach chair. *  (b) Gray stone,large, Very light,floats. * (c) Blue stone, large, heavy.  Press  a,  b,  or  c .',True, YELLOW)
        cShore2Rect=cShore2Surf.get_rect()
        cShore2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(cShore2Surf, cShore2Rect)
    
        cShore3Font=pygame.font.Font('freesansbold.ttf', 18)
        cShore3Surf=cShore3Font.render(
'Score, *  less time lost the more points you get,   //  Treasure,   *  Items to be found.', True, YELLOW)
        cShore3Rect=cShore3Surf.get_rect()
        cShore3Rect.midtop=(WINDOWWIDTH/2, 780)
        DISPLAYSURF.blit(cShore3Surf, cShore3Rect)

        islandFont=pygame.font.Font('freesansbold.ttf', 18)
        islandSurf=islandFont.render(
'Smugglers Island is to far to swim, the sea is calm and the tide is high.  **Clue *Tide is high**', True, YELLOW)
        islandRect=islandSurf.get_rect()
        islandRect.midtop=(WINDOWWIDTH/2, 805)
        DISPLAYSURF.blit(islandSurf, islandRect)
        checkForQuit()        
        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_a):
                    pygame.mixer.Sound.stop(oceanObj)                    
                    chair()
                      
                if (event.key==K_b):
                    pygame.mixer.Sound.stop(oceanObj)                     
                    grayStone()
                     
                if (event.key==K_c):
                    pygame.mixer.Sound.stop(oceanObj)                     
                    blueStone()
                     
        pygame.display.update()
        pygame.time.wait(500)
        FPSCLOCK.tick(FPS)
        
def timeLeft():
    while True:
        timeFont=pygame.font.Font('freesansbold.ttf', 70)
        timeSurf=timeFont.render("20  seconds  left.",True, GREEN)
        timeRect=timeSurf.get_rect()
        timeRect.midtop=(WINDOWWIDTH/2, 200)
        DISPLAYSURF.blit(timeSurf, timeRect)
        pygame.display.update()
        return

        
def puzMesB():
    while True:
        barpuzFont=pygame.font.Font('freesansbold.ttf', 70)
        barpuzSurf=barpuzFont.render('*Barrel Puzzle*', True, BLUE)
        barpuzRect = barpuzSurf.get_rect()
        barpuzRect.midtop =(WINDOWWIDTH /2, 300)
        DISPLAYSURF.blit(barpuzSurf, barpuzRect)
        pygame.display.update()    
        return
def puzMesS():
    while True:
        sorryFont=pygame.font.Font('freesansbold.ttf', 70)
        sorrySurf=sorryFont.render('*Sorry not there. *', True, BLUE)
        sorryRect = sorrySurf.get_rect()
        sorryRect.midtop =(WINDOWWIDTH /2, 300)
        DISPLAYSURF.blit(sorrySurf, sorryRect)
        pygame.display.update()    
        return
trys = 0                                
def ringAtoC():
    global ringP # ring position   1  , 2 , 3 

    while True:
        if random.randint(1, 3) == 1:
            ringP = 1
            DISPLAYSURF.fill(BLACK)
            DISPLAYSURF.blit(barrelPuz, (250, 30))        
            DISPLAYSURF.blit(ring, (390, 290))
            pygame.display.update()
            return        
        
        if random.randint(1, 3) == 2:
            ringP = 2
            DISPLAYSURF.fill(BLACK)
            DISPLAYSURF.blit(barrelPuz, (250, 30))      
            DISPLAYSURF.blit(ring, (605, 290))
            pygame.display.update()
            return            
        
        if random.randint(1, 3) == 3:
            ringP = 3
            DISPLAYSURF.fill(BLACK)
            DISPLAYSURF.blit(barrelPuz, (250, 30))          
            DISPLAYSURF.blit(ring, (845, 290))        
            pygame.display.update()
            return   
                    
def cupA():
    global ringP
    global score
    global trys
    trys +=1   
    while True:         
        DISPLAYSURF.blit(barrelPuzA, (250, 30))        
        pygame.display.update()
        pygame.time.wait(2000)
        checkForQuit()        
        if trys < 3 and ringP != 1: # wrong guess
            barrelPuzzle()
        if trys == 1 and ringP == 1:
            score += 30 # first guess
            blueTunnel()
        if trys == 2 and ringP == 1:
            score += 20  # second guess
            blueTunnel()
        if trys == 3 and ringP == 1:
            score += 10  # third guess
            blueTunnel()
        if trys == 3:    # end
            blueTunnel()

        
def cupB():
    global ringP
    global score
    global trys
    trys += 1    
    while True:           
        DISPLAYSURF.blit(barrelPuzB, (250, 30))        
        pygame.display.update()
        pygame.time.wait(2000)
        checkForQuit()         
        if trys < 3 and ringP != 2:
            barrelPuzzle()
        if trys == 1 and ringP == 2:
            score += 30
            blueTunnel()
        if trys == 2 and ringP == 2:
            score += 20
            blueTunnel()
        if trys == 3 and ringP == 2:
            score += 10
            blueTunnel()
        if trys == 3:
            blueTunnel() 

        
def cupC():
    global ringP
    global score
    global trys
    trys += 1    
    while True:      
        DISPLAYSURF.blit(barrelPuzC, (250, 30))     
        pygame.display.update()
        pygame.time.wait(2000)
        checkForQuit()        
        if trys < 3 and ringP != 3:
            barrelPuzzle()
        if trys == 1 and ringP == 3:
            score += 30
            blueTunnel()
        if trys == 2 and ringP == 3:
            score += 20
            blueTunnel()
        if trys == 3 and ringP == 3:
            score += 10
            blueTunnel()
        if trys == 3:
            blueTunnel()                      


def barrelPuzzle():
    global trys
    global score
    while True:                                       #  pos       rect size
        cupA1TRAN_RECT = pygame.Rect(375, 270, 60, 60) #x and y , size x  size  y    cup1 
        cupB1TRAN_RECT = pygame.Rect(590, 270, 60, 60) #x and y , size x  size  y    cup2    
        cupC1TRAN_RECT = pygame.Rect(830, 270, 60, 60) #x and y , size x  size  y    cup3
        
        pygame.draw.rect(DISPLAYSURF,WHITE, cupA1TRAN_RECT)# white rect under background  cup1       
        pygame.draw.rect(DISPLAYSURF,WHITE, cupB1TRAN_RECT)# white rect under background  cup2
        pygame.draw.rect(DISPLAYSURF,WHITE, cupC1TRAN_RECT)# white rect under background  cup3      
    
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(barrelPuzS, (250, 30))
                
        trysSurf=BIGFONT.render("Trys :" + str(trys), True, RED)
        trysRect=trysSurf.get_rect()
        trysRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(trysSurf, trysRect)
        
        scoreSurf=BIGFONT.render("score :" + str(score), True, RED)
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-600, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)        
        
        barrFont=pygame.font.Font('freesansbold.ttf', 24)
        barrSurf=barrFont.render(
"* Ted's lost his ring, *" , True, YELLOW)
        barrRect=barrSurf.get_rect()
        barrRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(barrSurf, barrRect)
        
        barr2Font=pygame.font.Font('freesansbold.ttf', 24)
        barr2Surf=barr2Font.render(
'*You  get 30 points first try, 20 points second try ,10 points third try .* ', True, YELLOW)
        barr2Rect=barr2Surf.get_rect()
        barr2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(barr2Surf, barr2Rect)
        
        barr3Font=pygame.font.Font('freesansbold.ttf', 24)
        barr3Surf=barr3Font.render(
'* Try your luck and pick a cup. *', True, YELLOW)
        barr3Rect=barr3Surf.get_rect()
        barr3Rect.midtop=(WINDOWWIDTH/2, 790)
        DISPLAYSURF.blit(barr3Surf, barr3Rect)
        
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and cupA1TRAN_RECT.collidepoint(event. pos):      
                ringAtoC()
                cupA()
            if event.type == MOUSEBUTTONUP and cupB1TRAN_RECT.collidepoint(event. pos):
                ringAtoC() 
                cupB()
                
            if event.type == MOUSEBUTTONUP and cupC1TRAN_RECT.collidepoint(event. pos):
                ringAtoC()            
                cupC()  
   
        pygame.display.update() 

        
def tresCave2(): #clue / ring  / grin  / x=w y= h
    DISPLAYSURF.fill(BLACK)                 #    rect pos        rect size
    XaTRAN_RECT = pygame.Rect(450, 330, 180, 80)  #x and y    / size x  size  y  glases   white   
    RaTRAN_RECT = pygame.Rect(790, 350, 130, 50)  #x and y    / size x  size  y  cups     white   
    X2aTRAN_RECT = pygame.Rect(320, 450, 660, 150) #x and y   / size x  size  y  barrels  green
    X3aTRAN_RECT = pygame.Rect(330, 480, 40, 50)  #x and y    / size x  size  y  candle   green
    
    while True:
        global score
        global tres        
        pygame.draw.rect(DISPLAYSURF,WHITE, XaTRAN_RECT)####  white rect under background  glases       
        pygame.draw.rect(DISPLAYSURF,WHITE, RaTRAN_RECT)####  white rect under background  cups
        pygame.draw.rect(DISPLAYSURF,GREEN, X2aTRAN_RECT)#### green rect under background  barrels
        pygame.draw.rect(DISPLAYSURF,GREEN, X3aTRAN_RECT)#### green rect under background  candle
        
        DISPLAYSURF.blit(tresCave_SURF, (5, 5))
        DISPLAYSURF.blit(candle1A_SURF, (260, 360))
        
        DISPLAYSURF.blit(booz_SURF, (50, 80))#ok
        DISPLAYSURF.blit(ted2Front_SURF,(50, 330))
        DISPLAYSURF.blit(bela, (1050, 420))    
        pygame.display.update()        
        pygame.time.wait(100)        
             
        scoreSurf=BIGFONT.render('Score :  '+ str(score), True, RED) 
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH- 300, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        
        scoreSurf=BIGFONT.render('Treasure :  '+ str(tres), True, RED)
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH- 600, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"* Ted's lost his ring, *" ,True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)
        
        chest2Font=pygame.font.Font('freesansbold.ttf', 24)
        chest2Surf=chest2Font.render(
'*You can get 30 points if you find it first time .* ', True, YELLOW)
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)
        
        chest3Font=pygame.font.Font('freesansbold.ttf', 24)
        chest3Surf=chest3Font.render(
'*You will need a bit of luck.*', True, YELLOW)
        chest3Rect=chest3Surf.get_rect()
        chest3Rect.midtop=(WINDOWWIDTH/2, 790)
        DISPLAYSURF.blit(chest3Surf, chest3Rect)
        DISPLAYSURF.blit(candle1B_SURF, (260, 360))
        DISPLAYSURF.blit(flash, (700, 550))
        DISPLAYSURF.blit(flash, (520, 360))

        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and RaTRAN_RECT.collidepoint(event. pos):
                puzMesB()
                pygame.display.update()                
                pygame.time.wait(2000)                 
                barrelPuzzle()
            if event.type == MOUSEBUTTONUP and XaTRAN_RECT.collidepoint(event. pos):
                puzMesS()
                pygame.display.update()
                pygame.time.wait(2000)
                tresCave2()
            if event.type == MOUSEBUTTONUP and X2aTRAN_RECT.collidepoint(event. pos):
                puzMesS()
                pygame.display.update()
                pygame.time.wait(2000)
                tresCave2()                
            if event.type == MOUSEBUTTONUP and X3aTRAN_RECT.collidepoint(event. pos):#candle
                puzMesS()
                pygame.display.update()
                pygame.time.wait(2000)
                tresCave2()
        pygame.display.update()        
        pygame.time.wait(1000) 
        FPSCLOCK.tick(FPS)


def mouseRun(): ## walk / run away / & angles/
    mouseimg=pygame.image.load('mice.png').convert()
    mousCavBB_SURF=pygame.image.load('mouseCaveBBla.png').convert()
    
    while True:
        FPS=30  
        width = 140  #start size
        height = 140
        
        mousex=600  # w   start position
        mousey=480  # h

        direction='up'
        while True:
            mousesObj.play()
            if direction=='up':
                mousex -= 18 # +> angle to right / - < angle to left / del for strait
                mousey -= 10 # forward steps
                width -= 7  # size
                height -= 7 # size
                        
                DISPLAYSURF.fill(BLACK)
                DISPLAYSURF.blit(mousCavBB_SURF, (5, 5))
                mouse = pygame.transform.scale(mouseimg, (width, height))
                
                DISPLAYSURF.blit(mouse, (mousex, mousey))            
                pygame.display.update()            
                pygame.time.wait(100) 
                
                if mousey <= 280:
                    pygame.time.wait(1000)
                    pygame.mixer.Sound.stop(mousesObj)
                    return# sent back to program                                       
    FPSCLOCK.tick(FPS)#ok
    
def tresMouseCave():  #ok #mouseRun()                   
    mouseCave_SURF =pygame.image.load('mouseCaveBBla.png').convert()
    DISPLAYSURF.blit(mouseCave_SURF, (5, 5))
    pygame.display.update()
    mouseRun()
    pygame.display.update()
    TRAN_RECT = pygame.Rect(470, 180, 20, 100) #x and y , size x  size  y
    while True:
        pygame.draw.rect(DISPLAYSURF,WHITE, TRAN_RECT)#### white rect under background 
        DISPLAYSURF.blit(mouseCave_SURF, (5, 5))      
    
        scoreSurf=BIGFONT.render('Score :  '+ str(score), True, RED) 
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH- 300, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        
        scoreSurf=BIGFONT.render('Treasure :  '+ str(tres), True, RED) 
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH- 600, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        
        mice2Font=pygame.font.Font('freesansbold.ttf', 24)
        mice2Surf=mice2Font.render(
'*There are a lot of mice in this tunnel .* ', True, YELLOW)
        mice2Rect=mice2Surf.get_rect()
        mice2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(mice2Surf, mice2Rect)
        
        mice3Font=pygame.font.Font('freesansbold.ttf', 24)
        mice3Surf=mice3Font.render(
'* You can play with one or press  , c , to continue.*', True, YELLOW)
        mice3Rect=mice3Surf.get_rect()
        mice3Rect.midtop=(WINDOWWIDTH/2, 790)
        DISPLAYSURF.blit(mice3Surf, mice3Rect)
        pygame.display.update()

        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and TRAN_RECT.collidepoint(event. pos):
                walkRun2()
            if event.type == KEYUP:
                if (event.key == K_c):
                    blueTunnel()                            
        pygame.display.update()        

def walkRun2(): ## walk / run away / & angles   ok
    global walk1img, walk2img, backDrop_SURF 
    walk1img=pygame.image.load('tedBackWalk1Small.png').convert()
    walk2img=pygame.image.load('tedBackWalk2Small.png').convert()    
    backDrop_SURF=pygame.image.load('mouseCaveBBla.png').convert()
    DISPLAYSURF.fill(BLACK)
        
    mice22Font=pygame.font.Font('freesansbold.ttf', 24)
    mice22Surf=mice22Font.render(
'* You have found a treasure cave .* ', True, YELLOW)
    mice22Rect=mice22Surf.get_rect()
    mice22Rect.midtop=(WINDOWWIDTH/2, 760)
    DISPLAYSURF.blit(mice22Surf, mice22Rect)
        
    mice33Font=pygame.font.Font('freesansbold.ttf', 24)
    mice33Surf=mice33Font.render(
'* Ted can test his luck.*', True, YELLOW)
    mice33Rect=mice33Surf.get_rect()
    mice33Rect.midtop=(WINDOWWIDTH/2, 790)
    DISPLAYSURF.blit(mice33Surf, mice33Rect)
    pygame.display.update()

    while True:
        FPS=30  
        width = 160  ## size  of  ted
        height = 260
        
        walk1bx=570  # w start  positions
        walk1by=320 #  h
        walk2bx=570  # w 
        walk2by=310  # h  

        direction='up'
        while True:    
            if direction=='up':
                walk1bx -= 10 # +> angle to right / - < angle to left / del for strait
                walk1by -= 6  # steps forward
                width -= 3   # size of ted   - smaller / + larger
                height -= 5   # size of ted
                        
                DISPLAYSURF.blit(blacka, (5, 5))
                DISPLAYSURF.blit(backDrop_SURF, (5, 5))
                ted = pygame.transform.scale(walk1img, (width, height))
                
                DISPLAYSURF.blit(ted, (walk1bx, walk1by))            
                pygame.display.update()            
                pygame.time.wait(300) ##500 for walk //100 for run
    
                walk2by = walk1by  #  steps forward
                walk2bx = walk1bx  # > / < angles
                
                walk1bx -= 10 # +> angle to right / - < angle to left / del for strait
                walk2by -= 6  # steps forward              
                width -= 3   # size of ted
                height -= 5   # size
                              
                DISPLAYSURF.blit(blacka, (5, 5))
                DISPLAYSURF.blit(backDrop_SURF, (5, 5))
                ted2 = pygame.transform.scale(walk2img, (width, height))
                
                DISPLAYSURF.blit(ted2, (walk2bx, walk2by))       
                pygame.display.update()             
                pygame.time.wait(300)  # 500 for walk // 100 for run
                
                walk1by = walk2by  # steps forward
                walk1bx = walk2bx  # > / < angles
                
                if walk1by <= 170:  # end point
                    pygame.time.wait(1000)                
                    tresCave2()#return# sent back to program #  tresCave()                  
                if walk2by <= 170:  # end point
                    pygame.time.wait(1000)                   
                    tresCave2()#return#  sent back  #  tresCave()                      
    FPSCLOCK.tick(FPS)

def startBarrelPuz():##to tresMouseCave    from climb  
    global score
    score += 5
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(eye_SURF, (700, 300))
        toStartFont=pygame.font.Font('freesansbold.ttf', 24)
        toStartSurf=toStartFont.render(
'You have scored 5 out of 10 . not the top score,next is the blue tunnel.', True, YELLOW)
        toStartRect=toStartSurf.get_rect()
        toStartRect.midtop=(WINDOWWIDTH/2, 780)
        DISPLAYSURF.blit(toStartSurf, toStartRect)
        startKeyMes()
        if keyPress():
            pygame.event.get()
            tresMouseCave()  
        pygame.display.update()        
        
        
def climb(): ##climb down rope
    climbimg=pygame.image.load('tedRope.png')
    climbx=700
    climby=80
    direction='right'
    while True:
        DISPLAYSURF.blit(caveFallRope_SURF, (5, 5))
        pleaseWait()
        if direction=='right':
            climbx+=5
            if climbx==810:
                direction='down'
        elif direction=='down':
            climby+=5
            if climby==560:
                pygame.time.wait(5000)
                startBarrelPuz()
                
        DISPLAYSURF.blit(climbimg, (climbx, climby))        
        pygame.display.update()
        FPSCLOCK.tick(FPS)##

def redTunnelEnd():##score+10
    global score
    score +=10
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(eye_SURF, (700, 300))
            
        redFont=pygame.font.Font('freesansbold.ttf', 24)
        redSurf=redFont.render(
'Ted found the fastest way down,score 10 out of 10. This way is to the blue tunnel', True, YELLOW)
        redRect=redSurf.get_rect()
        redRect.midtop=(WINDOWWIDTH/2, 780)
        DISPLAYSURF.blit(redSurf, redRect)
        startKeyMes()
        if keyPress():
            pygame.event.get()
            tresMouseCave()     
        pygame.display.update()      
        
def fall():# mCat
    DISPLAYSURF.fill(BLACK)
    redaFont=pygame.font.Font('freesansbold.ttf', 24)
    redaSurf=redaFont.render(
'Ted landed safely on a larg soft furry animal.', True, YELLOW)
    redaRect=redaSurf.get_rect()
    redaRect.midtop=(WINDOWWIDTH/2, 750)
    DISPLAYSURF.blit(redaSurf, redaRect)     
    fallimg=pygame.image.load('ted2Fall.png')
    fallx=800
    fally=100
    direction='right'
    while True:
        DISPLAYSURF.blit(caveFall_SURF, (5, 5))
        DISPLAYSURF.blit(mCat_SURF, (760, 620))
        pleaseWait()
        if direction=='right':
            fallx+=5
            if fallx==810:
                direction='down'
        elif direction=='down':
            fally+=5
            if fally==200:
                honkObj.play()
            if fally==590:
                pygame.time.wait(5000)
                pygame.mixer.Sound.stop(honkObj)
                redTunnelEnd()
                
        DISPLAYSURF.blit(fallimg, (fallx, fally))        
        pygame.display.update()    
        
        
def rope(): ##ted and rope icon
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(cave2_SURF, (5, 5))
        DISPLAYSURF.blit(rope_SURF, (600, 620))
        cave2aFont=pygame.font.Font('freesansbold.ttf', 24)
        cave2aSurf=cave2aFont.render(
'You have picked the coil of rope with a hook, It looks usefull.Enter the tunnel.',True, YELLOW)
        cave2aRect=cave2aSurf.get_rect()
        cave2aRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(cave2aSurf, cave2aRect)
        eyes()
        pygame.display.update()

def tunnelRope():##chest no key
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chesta_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))#ok
        
        tunRope1Font=pygame.font.Font('freesansbold.ttf', 24)
        tunRope1Surf=tunRope1Font.render(
'In the tunnel Ted finds an old chest. It may contain treasure',True, YELLOW)
        tunRope1Rect=tunRope1Surf.get_rect()
        tunRope1Rect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(tunRope1Surf, tunRope1Rect)
        
        tunRopeFont=pygame.font.Font('freesansbold.ttf', 24)
        tunRopeSurf=tunRopeFont.render(
"But it's locked ,Ted has not got a key .You picked the rope.  Press  ,  c  , To continue",True, YELLOW)
        tunRopeRect=tunRopeSurf.get_rect()
        tunRopeRect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(tunRopeSurf, tunRopeRect)
        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_c):
                    tunnelEndA()        
        pygame.display.update()

def tunnelEndA():##ted + rope + fall
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(rope_SURF, (600, 400))
        DISPLAYSURF.blit(ted2Front_SURF, (400, 300))
        tunEndAFont=pygame.font.Font('freesansbold.ttf', 24)
        tunEndASurf=tunEndAFont.render(
'At the end of the tunnel is long drop into a deep cavern. ',True, YELLOW)
        tunEndARect=tunEndASurf.get_rect()
        tunEndARect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(tunEndASurf, tunEndARect)

        tunEndBFont=pygame.font.Font('freesansbold.ttf', 24)
        tunEndBSurf=tunEndBFont.render(
'Ted secures the hook to climb down the rope. ',True, YELLOW)
        tunEndBRect=tunEndBSurf.get_rect()
        tunEndBRect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(tunEndBSurf, tunEndBRect)        
        startKeyMes()
        if keyPress():
            pygame.event.get()
            caveFallRope()
        pygame.display.update()

def caveFallRope():##ted fall ,retun tunnel
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(caveFallRope_SURF, (5, 5))
        caveFrFont=pygame.font.Font('freesansbold.ttf', 24)
        caveFrSurf=caveFrFont.render(
'Finding a place to secure his hook and climb down, Ted lost time .But you got him there safe and alive.',True, YELLOW)
        caveFrRect=caveFrSurf.get_rect()
        caveFrRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveFrSurf, caveFrRect)        
        caveFraFont=pygame.font.Font('freesansbold.ttf', 24)
        caveFraSurf=caveFraFont.render(
'Try the next tunnel',True, YELLOW)
        caveFraRect=caveFraSurf.get_rect()
        caveFraRect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(caveFraSurf, caveFraRect)
        climb()
        startKeyMes()
        if keyPress():
            pygame.event.get()
            toStart()#  bypessed  by /barrel puzzle/
        pygame.display.update()###ok no time

def redStone(): ##red stone icon
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(cave2_SURF, (5, 5))        
        DISPLAYSURF.blit(redStone_SURF, (640, 620))
        rStoneFont=pygame.font.Font('freesansbold.ttf', 24)
        rStoneSurf=rStoneFont.render(
"You have picked the lucky red stone. It may bring him luck.",True, YELLOW)
        rStoneRect=rStoneSurf.get_rect()
        rStoneRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(rStoneSurf, rStoneRect)
        eyes2()
        pygame.display.update()###ok no time
        
def eyes2():
    startKeyMes()
    eyeimg=pygame.image.load('eyesaa.png')
    eyex=550
    eyey=400
    direction='right'
    while True:
        DISPLAYSURF.blit(cave2_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        if direction=='right':
            eyex+=5 #3#ok
            if eyex==800:#ok
                pygame.time.wait(5000)
                rStoneTunnel()                 
        DISPLAYSURF.blit(eyeimg, (eyex, eyey))        
        pygame.display.update()
        FPSCLOCK.tick(FPS)
        
def key():##open chest   ##score 5 tresure points and ted flip 
    DISPLAYSURF.fill(BLACK)
    global tres
    tres += 5
    while True:
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chestb_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(tres_SURF, (600, 400))
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"The treasure chest is open,  5  treasure points for Ted ",True, YELLOW)##tunnel and chest open 
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)  #0k
        pygame.display.update()
        pygame.time.wait(5000)
        flip()
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chestb_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Front_SURF, (400, 350))
        DISPLAYSURF.blit(tres_SURF, (600, 400))
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"      ted's  Happy ",True, YELLOW)##tunnel and chest open 
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)  #ok
        pygame.display.update()
        pygame.time.wait(2000)        

        startKeyMes()
        pygame.display.update()        
        pygame.time.wait(10000)         
        if keyPress():
            pygame.event.get()
            redStoneTunnel2()
        redStoneTunnel2()          
        pygame.display.update()
        FPSCLOCK.tick(FPS)
        
def redStoneTunnel2():##tunnel end 'fall on mer/cat
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(eye_SURF, (700, 300))
        DISPLAYSURF.blit(redStone_SURF, (600, 400))
        toStartFont=pygame.font.Font('freesansbold.ttf', 24)
        toStartSurf=toStartFont.render(
'At the end of the tunnel is a long drop to a deep cavern .Ted slips off the edge and falls.  Press ,  c  ,  continue.', True, YELLOW)
        toStartRect=toStartSurf.get_rect()
        toStartRect.midtop=(WINDOWWIDTH/2, 780)
        DISPLAYSURF.blit(toStartSurf, toStartRect)
        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_c):
                    fall()          
        pygame.display.update()          
        
def rStoneTunnel():## chest puz#timer  60 secs#0k
    startTime=0#ok
    startTime=time.time() #ok   
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chesta_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))#ok        
        rStoneFont=pygame.font.Font('freesansbold.ttf', 24)
        rStoneSurf=rStoneFont.render(
'In the tunnel Ted finds an old chest. It may contain treasure, you have to find the key to lift the lid.',True, YELLOW)
        rStoneRect=rStoneSurf.get_rect()
        rStoneRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(rStoneSurf, rStoneRect)        
        rStone2Font=pygame.font.Font('freesansbold.ttf', 24)
        rStone2Surf=rStone2Font.render(
'Clue.**The key that waits in line.** If you can not find the key, press  p to pass.You have 80 seconds',True, YELLOW)
        rStone2Rect=rStone2Surf.get_rect()
        rStone2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(rStone2Surf, rStone2Rect)
        if time.time() - 60 > startTime:
            timeLeft()
            if time.time() -80 > startTime:
                redStoneTunnel2()         
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_q):
                    key()
                elif (event.key==K_p):               
                    redStoneTunnel2()
            pygame.display.update()
            FPSCLOCK.tick(FPS)
           
def tunnelKey():##chest & key
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chesta_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        
        tunKeyFont=pygame.font.Font('freesansbold.ttf', 24)
        tunKeySurf=tunKeyFont.render(
'In the tunnel Ted finds an old chest. It may contain treasure',True, YELLOW)
        tunKeyRect=tunKeySurf.get_rect()
        tunKeyRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(tunKeySurf, tunKeyRect)
        
        tunKey2Font=pygame.font.Font('freesansbold.ttf', 24)
        tunKey2Surf=tunKey2Font.render(
"It's locked .Ted can use the key,  Press  ,  k  , to open the chest.",True, YELLOW)
        tunKey2Rect=tunKey2Surf.get_rect()
        tunKey2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(tunKey2Surf, tunKey2Rect)
        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_k):
                    keyB()      
        pygame.display.update()
        
def eyes3():#from  
    eyeimg=pygame.image.load('eyesaa.png')
    eyex=550
    eyey=400
    direction='right'
    while True:
        DISPLAYSURF.blit(cave2_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        pleaseWait()
        if direction=='right':
            eyex+=5
            if eyex==800:
                pygame.time.wait(5000)
                tunnelKey()                 
        DISPLAYSURF.blit(eyeimg, (eyex, eyey))        
        pygame.display.update()
        FPSCLOCK.tick(FPS)            
            
def pickKey():#  sound  ???
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(cave2_SURF, (5, 5))        
        DISPLAYSURF.blit(key_SURF, (640, 620))
        keyFont=pygame.font.Font('freesansbold.ttf', 24)
        keySurf=keyFont.render(
"You have picked the unlucky key .Ted's not happy.",True, YELLOW)
        keyRect=keySurf.get_rect()
        keyRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(keySurf, keyRect)
        eyes3()
        pygame.display.update()

def keyB():##open chest empty
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chestb_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(noteS_SURF, (540, 400))
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"The treasure chest is open, The chest is empty, There is a note.",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)
        
        chest2Font=pygame.font.Font('freesansbold.ttf', 24)
        chest2Surf=chest2Font.render(
"The note reads **  This tunnel leads back to were you started **, Ted's not happy. Press ,  c  , to continue.",True, YELLOW)###??
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)
        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_c):
                    keyTunEnd()          
        pygame.display.update()

def keyTunEnd():##tunnel end 'fall game over
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(eye_SURF, (700, 300))
        DISPLAYSURF.blit(key_SURF, (600, 400))
        gaOvFont=pygame.font.Font('freesansbold.ttf', 24)
        gaOvSurf=gaOvFont.render(
'At the end of the tunnel is a long drop to a deep caven .Ted slips of the edge and falls.', True, YELLOW)
        gaOvRect=gaOvSurf.get_rect()
        gaOvRect.midtop=(WINDOWWIDTH/2, 780)
        DISPLAYSURF.blit(gaOvSurf, gaOvRect)
        startKeyMes()
        if keyPress():
            pygame.event.get()
            fallGaOv()      
        pygame.display.update()

def fallGaOv():# game over from key
    
    DISPLAYSURF.fill(BLACK)
    tedKFont=pygame.font.Font('freesansbold.ttf', 24)
    tedKSurf=tedKFont.render(
'***You have killed Ted !***.', True, YELLOW)
    tedKRect=tedKSurf.get_rect()
    tedKRect.midtop=(WINDOWWIDTH/2, 750)
    DISPLAYSURF.blit(tedKSurf, tedKRect)
    pleaseWait()
    fallimg=pygame.image.load('ted2Fall.png')
    fallx=800
    fally=100
    direction='right'
    while True:
        DISPLAYSURF.blit(caveFall_SURF, (5, 5))
        if direction=='right':
            fallx+=5
            if fallx==810:
                direction='down'
        elif direction=='down':
            fally+=5
            if fally==200:
                thumpObj.play()
            if fally==620:
                
                pygame.time.wait(3000)                
                gameOver()               
        DISPLAYSURF.blit(fallimg, (fallx, fally))        
        pygame.display.update()            
        

def caveTwo():##start cave 2 + icons score total##    bat
    global fly1img, fly2img, fly3img,  backDrop_SURF, halfDrop_SURF, patch_SURF
    fly1img=pygame.image.load('bat1.png')
    fly2img=pygame.image.load('bat2.png')
    fly3img=pygame.image.load('bat3.png')       
    backDrop_SURF=pygame.image.load('cave2.png').convert()
    halfDrop_SURF=pygame.image.load('caveHalf2.png').convert()
    patch_SURF=pygame.image.load('cave2Patch.png').convert()   
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(cave2_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF, (150, 320))
        DISPLAYSURF.blit(rope_SURF, (350, 620))
        DISPLAYSURF.blit(redStone_SURF, (540, 620))
        DISPLAYSURF.blit(key_SURF, (780, 620))       
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)###ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)

        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)###ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)        
        cave2Font=pygame.font.Font('freesansbold.ttf', 18)
        cave2Surf=cave2Font.render(
'Inside the cave is a very dark tunnel entrance, on the floor are 3 items, you may only pick one.',True, YELLOW)
        cave2Rect=cave2Surf.get_rect()
        cave2Rect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(cave2Surf, cave2Rect)        
        cave22Font=pygame.font.Font('freesansbold.ttf', 18)
        cave22Surf=cave22Font.render(
'Items, *  (a) Rope with hook.  * (b)  Red stone ,small *  (c)  Key, small */  Press  a,  b,  or  c .',True, YELLOW)
        cave22Rect=cave22Surf.get_rect()
        cave22Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(cave22Surf, cave22Rect)        
        cave23Font=pygame.font.Font('freesansbold.ttf', 18)
        cave23Surf=cave23Font.render(
' Goal  *  get Ted to the end of the tunnel alive ,pick the item you think will get him there quickly and safe .',True, YELLOW)
        cave23Rect=cave23Surf.get_rect()
        cave23Rect.midtop=(WINDOWWIDTH/2, 780)
        DISPLAYSURF.blit(cave23Surf, cave23Rect)
        checkForQuit()        
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_a):
                    batFly()
                    rope()
                if (event.key==K_b):
                    batFly()
                    redStone()
                if (event.key==K_c):
                    batFly()
                    pickKey()                   
        pygame.display.update()
        
def eyes():
    eyeimg=pygame.image.load('eyesaa.png')#####ok
    eyex=550
    eyey=400
    direction='right'
    while True:
        DISPLAYSURF.blit(cave2_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        pleaseWait()
        if direction=='right':
            eyex+=5
            if eyex==800:
                pygame.time.wait(5000)
                tunnelRope()                 
        DISPLAYSURF.blit(eyeimg, (eyex, eyey))        
        pygame.display.update()
        FPSCLOCK.tick(FPS)
        
def opChestGrSTun():##back to start ###add score -2  tres -1
    global score
    score -=2
    global tres
    tres -=1
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chestb_SURF, (700, 500))
        DISPLAYSURF.blit(ted2Front_SURF, (400, 350))
        DISPLAYSURF.blit(fairyA_SURF, (900, 300))
        DISPLAYSURF.blit(battery_SURF, (640, 500))
        DISPLAYSURF.blit(noteS_SURF, (530, 370))
        
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"The chest is open, inside is a torch battery ,but you do not have a torch.",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)
        
        chest2Font=pygame.font.Font('freesansbold.ttf', 24)
        chest2Surf=chest2Font.render(
"There is a note .It reads ,** This tunnel leads back to were you started**.",True, YELLOW)
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)
        
        chest3Font=pygame.font.Font('freesansbold.ttf', 24)
        chest3Surf=chest3Font.render(
"You have lost 2 points off your score and lost 1 treasure point.",True, YELLOW)
        chest3Rect=chest3Surf.get_rect()
        chest3Rect.midtop=(WINDOWWIDTH/2, 790)
        DISPLAYSURF.blit(chest3Surf, chest3Rect)        
        startKeyMes()
        if keyPress():
            pygame.event.get()
            blueTunnel()
        pygame.display.update()
        
def opChestGrSTunNoBat():##back to start no batterys##add  score -2   tres -1
    global score
    score -=2
    global tres
    tres -=1
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chestb_SURF, (700, 500))
        DISPLAYSURF.blit(ted2Front_SURF, (400, 350))
        DISPLAYSURF.blit(fairyA_SURF, (900, 300))
        DISPLAYSURF.blit(note_SURF, (530, 370))
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"The chest is open, inside is a note,it reads,**Sorry run out of batterys.**",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)
        
        chest2Font=pygame.font.Font('freesansbold.ttf', 24)
        chest2Surf=chest2Font.render(
"** This tunnel leads back to were you started, you have lost 2 point and 1 treasure point. **.",True, YELLOW)
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)        
        startKeyMes()
        if keyPress():
            pygame.event.get()
            blueTunnel()
        pygame.display.update()        
def greenStoneTunTorch(): ####to opChestGrSTun2#timer 60 + 20#ok
    startTime=0#ok
    startTime=time.time()#ok    
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chesta_SURF, (700, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(fairyA_SURF, (900, 300))
        tunKeyFont=pygame.font.Font('freesansbold.ttf', 24)
        tunKeySurf=tunKeyFont.render(
"In the tunnel Ted finds an old chest. It may contain treasure,it'locked you need a key",True, YELLOW)
        tunKeyRect=tunKeySurf.get_rect()
        tunKeyRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(tunKeySurf, tunKeyRect)
        
        tunKey2Font=pygame.font.Font('freesansbold.ttf', 24)
        tunKey2Surf=tunKey2Font.render(
"Clue** the key that marks the spot**,  or press  p  to pass .You have 60 seconds.",True, YELLOW)
        tunKey2Rect=tunKey2Surf.get_rect()
        tunKey2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(tunKey2Surf, tunKey2Rect)
        if time.time() - 60 > startTime:
            timeLeft()
            if time.time() -80 > startTime:
                blueTunnel()         
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_x):
                    opChestGrSTunNoBat()
                elif (event.key==K_p):                
                    blueTunnel()        
            pygame.display.update()
            FPSCLOCK.tick(FPS)
def greenStoneTun():#####to opChestGrSTun###ok  timer 60  + 20##ok
    startTime=0#ok
    startTime=time.time() #ok     
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chesta_SURF, (700, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(fairyA_SURF, (900, 300))
        tunKeyFont=pygame.font.Font('freesansbold.ttf', 24)
        tunKeySurf=tunKeyFont.render(
"In the tunnel Ted finds an old chest. It may contain treasure,it'locked you need a key",True, YELLOW)
        tunKeyRect=tunKeySurf.get_rect()
        tunKeyRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(tunKeySurf, tunKeyRect)
        
        tunKey2Font=pygame.font.Font('freesansbold.ttf', 24)
        tunKey2Surf=tunKey2Font.render(
"Clue** You need the key that lets you see inside the chest,  or press  p  to pass .You have 60 seconds .",True, YELLOW)
        tunKey2Rect=tunKey2Surf.get_rect()
        tunKey2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(tunKey2Surf, tunKey2Rect)
        if time.time() - 60 > startTime:
            timeLeft()
            if time.time() -80 > startTime:
                blueTunnel()         
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_i):
                    opChestGrSTun()
                elif (event.key==K_p):                
                    blueTunnel()        
            pygame.display.update()
            FPSCLOCK.tick(FPS)
            
def greenStone():##start
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(bTunn_SURF, (5, 5))
        DISPLAYSURF.blit(greenS_SURF, (550, 600))        
        DISPLAYSURF.blit(ted2Front_SURF,(30, 320))
        caveBL3Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL3Surf=caveBL3Font.render(
' You have picked the green stone .Now pick a tunnel and type ,11 , 12 or 13.',True, YELLOW)
        caveBL3Rect=caveBL3Surf.get_rect()
        caveBL3Rect.midtop=(WINDOWWIDTH/2, 780)
        DISPLAYSURF.blit(caveBL3Surf, caveBL3Rect)
        
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_1):
                    greenStoneTun()
                if (event.key==K_2):
                    greenStoneTun()
                if (event.key==K_3):
                    greenStoneTun() 
        pygame.display.update()
        
def torch():##back to start
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(bTunn_SURF, (5, 5))
        DISPLAYSURF.blit(torch_SURF, (550, 600))        
        DISPLAYSURF.blit(ted2Front_SURF,(30, 320))
        caveBL3Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL3Surf=caveBL3Font.render(
' You have picked the torch with no battery  ? .Now pick a tunnel and type ,11 , 12 or 13.',True, YELLOW)
        caveBL3Rect=caveBL3Surf.get_rect()
        caveBL3Rect.midtop=(WINDOWWIDTH/2, 780)
        DISPLAYSURF.blit(caveBL3Surf, caveBL3Rect)
        
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_1):
                    greenStoneTunTorch()
                if (event.key==K_2):
                    greenStoneTunTorch()
                if (event.key==K_3):
                    greenStoneTunTorch() 
        pygame.display.update()

def featherAn():
    DISPLAYSURF.fill(BLACK)
    tedKFont=pygame.font.Font('freesansbold.ttf', 24)
    tedKSurf=tedKFont.render(
'There is a draught from the middle tunnel blowing the feather', True, YELLOW)
    tedKRect=tedKSurf.get_rect()
    tedKRect.midtop=(WINDOWWIDTH/2, 750)
    DISPLAYSURF.blit(tedKSurf, tedKRect)
    startKeyMes()
    windObj.play()
    
    fallimg=pygame.image.load('feather.png')
    fallx=600
    fally=300
    direction='right'
    while True:
        DISPLAYSURF.blit(bTunn_SURF, (5, 60))##
        DISPLAYSURF.blit(ted2Front_SURF, (200, 400))
        if direction=='right':
            fallx+=5
            if fallx==900:
                direction='down'#ok
                
        elif direction=='down':#ok
            fally+=3
            if fally==600: #600 only      
                 pygame.time.wait(6000)
                 pygame.mixer.Sound.stop(windObj)
                 featherTun()               
        DISPLAYSURF.blit(fallimg, (fallx, fally))        
        pygame.display.update()
        FPSCLOCK.tick(FPS)
       
        
def featherTun4():##to water cave  score 10
    global score##score
    score +=10
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunHole_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF, (750, 350))
        DISPLAYSURF.blit(fairyA_SURF, (1100, 350))       
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"**The draught is from a hole in the wall, or we have a very windy fairy.**",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)
        
        chest2Font=pygame.font.Font('freesansbold.ttf', 24)
        chest2Surf=chest2Font.render(
"Ted climbs though the hole and finds the hidden tunnel.score 10 out of 10 .",True, YELLOW)
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)         
        chest3Font=pygame.font.Font('freesansbold.ttf', 24)
        chest3Surf=chest3Font.render(
"**  Press  ,  c  , to continue.**",True, YELLOW)
        chest3Rect=chest3Surf.get_rect()
        chest3Rect.midtop=(WINDOWWIDTH/2, 790)
        DISPLAYSURF.blit(chest3Surf, chest3Rect)        

        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_c):
                    waterCave()         
        pygame.display.update()     
    
def featherAn2():####  to tunnel featherTun4
    DISPLAYSURF.fill(BLACK)
    windObj.play()
    fallimg=pygame.image.load('feather.png')
    fallx=900
    fally=300
    direction='left'
    while True:
        DISPLAYSURF.blit(tunnel_SURF, (5, 60))
        DISPLAYSURF.blit(ted2Front_SURF, (800, 400))
        DISPLAYSURF.blit(fairyA_SURF, (1000, 350))
        pleaseWait()
        if direction=='left':
            fallx -= 5
            if fallx== 600:
                direction='down'#ok
                
        elif direction=='down':#ok
            fally+=3
            if fally==600: #ok
                 pygame.time.wait(4000)
                 pygame.mixer.Sound.stop(windObj)
                 featherTun4()               
        DISPLAYSURF.blit(fallimg, (fallx, fally))        
        pygame.display.update()     
        FPSCLOCK.tick(FPS)    
def featherTunnel3():
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF, (800, 350))
        DISPLAYSURF.blit(fairyA_SURF, (1000, 350))      
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"The draft in the tunnel blows the feather out of Ted's hand.**",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)
        
        chest2Font=pygame.font.Font('freesansbold.ttf', 24)
        chest2Surf=chest2Font.render(
"**The draft seems to come from behind the fairy ? **.",True, YELLOW)
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)        
        startKeyMes()
        if keyPress():
            pygame.event.get()
            featherAn2()
        pygame.display.update()
    
def featherTunnel2():###chest open and ted flip
    global tres
    tres += 5
    while True:                 
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chestb_SURF, (700, 500))
        DISPLAYSURF.blit(ted2Front_SURF, (400, 350))
        DISPLAYSURF.blit(fairyA_SURF, (900, 300))
        DISPLAYSURF.blit(tres_SURF, (600, 400))        
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"The chest is open, inside Ted finds 5 treasure points.**",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)
        pygame.display.update()
        pygame.time.wait(5000)        
        flip()               #ok
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chestb_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Front_SURF, (400, 350))
        DISPLAYSURF.blit(tres_SURF, (600, 400))
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"      ted's  Happy ",True, YELLOW)##tunnel and chest open 
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)  #ok
        pygame.display.update()
        pygame.time.wait(2000)          
        startKeyMes()
        pygame.display.update()        
        pygame.time.wait(10000)          
        if keyPress():
            pygame.event.get()
            featherTunnel3()
        featherTunnel3()            
        pygame.display.update()
        FPSCLOCK.tick(FPS)        
def featherTun():#######chest puz  ok  timer 60 + 10 
    startTime=0#ok
    startTime=time.time() #ok    
    while True:##ok
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chesta_SURF, (700, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(fairyA_SURF, (900, 300))
        tunKeyFont=pygame.font.Font('freesansbold.ttf', 24)
        tunKeySurf=tunKeyFont.render(
"In the tunnel Ted finds an old chest. It may contain treasure,it's locked you need a key",True, YELLOW)
        tunKeyRect=tunKeySurf.get_rect()
        tunKeyRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(tunKeySurf, tunKeyRect)
        
        tunKey2Font=pygame.font.Font('freesansbold.ttf', 24)
        tunKey2Surf=tunKey2Font.render(
"Clue**   The key you need for a quick get away ,  or press  p  to pass .You have 60 seconds.",True, YELLOW)
        tunKey2Rect=tunKey2Surf.get_rect()
        tunKey2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(tunKey2Surf, tunKey2Rect)
        if time.time() - 60 > startTime:
            timeLeft()
            if time.time() -80 > startTime:
                featherTunnel3() 
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_ESCAPE):
                    featherTunnel2()#open chest
                elif (event.key==K_p):                
                    featherTunnel3()        
            pygame.display.update()
            
def feather(): #to feather an
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(bTunn_SURF, (5, 5))
        DISPLAYSURF.blit(feather_SURF, (550, 600))        
        DISPLAYSURF.blit(ted2Front_SURF,(30, 320))
        caveBL3Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL3Surf=caveBL3Font.render(
' You have picked the feather .Ted drops the feather in front of the tunnels',True, YELLOW)
        caveBL3Rect=caveBL3Surf.get_rect()
        caveBL3Rect.midtop=(WINDOWWIDTH/2, 780)
        DISPLAYSURF.blit(caveBL3Surf, caveBL3Rect)
        startKeyMes()
        if keyPress():
            pygame.event.get()
            featherAn()
        pygame.display.update()                

def blueTunnel():##start of blue tunnel + icons    
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(bTunn_SURF, (5, 5))
        DISPLAYSURF.blit(greenS_SURF, (350, 600))
        DISPLAYSURF.blit(torch_SURF, (530, 600))
        DISPLAYSURF.blit(feather_SURF, (730, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 320))
                
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
'In front of the blue tunnels are 3 items, you may only pick one.',True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'Items, *  (a) Greenstone ,large , heavy.  * (b)  Torch but no battery *  (c)  Feather, small */  Press  a,  b,  or  c .',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        
        caveBL3Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL3Surf=caveBL3Font.render(
' Goal  *  Get Ted safely through the tunnel and find treasure points.',True, YELLOW)
        caveBL3Rect=caveBL3Surf.get_rect()
        caveBL3Rect.midtop=(WINDOWWIDTH/2, 780)
        DISPLAYSURF.blit(caveBL3Surf, caveBL3Rect)
        checkForQuit()        
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_a):
                    greenStone()
                if (event.key==K_b):
                    torch()
                if (event.key==K_c):
                    feather()
        pygame.display.update()

def hatA():##### to game over    
    DISPLAYSURF.fill(BLACK)
    tedHFont=pygame.font.Font('freesansbold.ttf', 24)
    tedHSurf=tedHFont.render(
"*** All that's left is his hat!***.", True, YELLOW)
    tedHRect=tedHSurf.get_rect()
    tedHRect.midtop=(WINDOWWIDTH/2, 750)
    DISPLAYSURF.blit(tedHSurf, tedHRect)
    pleaseWait()
    fallimg=pygame.image.load('hat.png')
    fallx=600
    fally=300
    direction='right'
    while True:
        DISPLAYSURF.blit(waterCave_SURF, (5, 5))
        if direction=='right':
            fallx+=2
            if fallx==1000:
                pygame.time.wait(5000)                
                gameOver()               
        DISPLAYSURF.blit(fallimg, (fallx, fally))    
        pygame.display.update()
        FPSCLOCK.tick(FPS)
        
     
def sharkFish1():# game over
    DISPLAYSURF.fill(BLACK)
    tedKFont=pygame.font.Font('freesansbold.ttf', 24)
    tedKSurf=tedKFont.render(
'***You have killed Ted !.  He is not happy ***.', True, YELLOW)
    tedKRect=tedKSurf.get_rect()
    tedKRect.midtop=(WINDOWWIDTH/2, 750)
    DISPLAYSURF.blit(tedKSurf, tedKRect)
    pleaseWait()
    fallimg=pygame.image.load('fish.png')
    fallx=200
    fally=300
    direction='right'
    while True:
        DISPLAYSURF.blit(madFish_SURF, (5, 5))

        if direction=='right':
            fallx+=5
            if fallx==1400:
                pygame.time.wait(5000)
                pygame.mixer.Sound.stop(underSeaObj)
                hatA()               
        DISPLAYSURF.blit(fallimg, (fallx, fally))   
        pygame.display.update()
        FPSCLOCK.tick(FPS)        
def ropeUnderSea():####fish  to sharkFish1
    while True:
        underSeaObj.play()
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(madFish_SURF, (5, 5))
        DISPLAYSURF.blit(ted2FallR_IMG, (900, 130))        
        caveWFont=pygame.font.Font('freesansbold.ttf', 24)
        caveWSurf=caveWFont.render(
'Ted swims for the boat but the shark has not gone away.He looks a very hungry fish.',True, YELLOW)
        caveWRect=caveWSurf.get_rect()
        caveWRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveWSurf, caveWRect)
        
        caveW2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveW2Surf=caveW2Font.render(
'The shark is going to eat Ted. ** Press ,  c  , to continue    **.',True, YELLOW)
        caveW2Rect=caveW2Surf.get_rect()
        caveW2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveW2Surf, caveW2Rect)
        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_c):
                    sharkFish1()  
        pygame.display.update()     

def ropeWater1():
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(waterCave_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF, (150, 320))
        DISPLAYSURF.blit(rope_SURF, (350, 620))
        
        caveWFont=pygame.font.Font('freesansbold.ttf', 24)
        caveWSurf=caveWFont.render(
'Ted throws the rope to try and hook the boat but the boat is to far away ,the rope is too short.',True, YELLOW)
        caveWRect=caveWSurf.get_rect()
        caveWRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveWSurf, caveWRect)
        
        caveW2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveW2Surf=caveW2Font.render(
'It looks like the shark has gone ,Ted jumps in the water to swim to the boat.',True, YELLOW)
        caveW2Rect=caveW2Surf.get_rect()
        caveW2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveW2Surf, caveW2Rect)###
        startKeyMes()
        if keyPress():
            pygame.event.get()
            ropeUnderSea()        
        pygame.display.update()
        
def blueStoneUnderSea():
    while True:
        underSeaObj.play()
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(madFish_SURF, (5, 5))
        DISPLAYSURF.blit(ted2FallR_IMG, (900, 130))
        DISPLAYSURF.blit(blueStone_SURF, (200, 500))
        caveWFont=pygame.font.Font('freesansbold.ttf', 24)
        caveWSurf=caveWFont.render(
'Ted swims for the boat but the shark has not gone away.He has a very sore head.',True, YELLOW)
        caveWRect=caveWSurf.get_rect()
        caveWRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveWSurf, caveWRect)
        
        caveW2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveW2Surf=caveW2Font.render(
'He looks very angry. The shark is going to eat Ted. ** Press ,  c  , to continue    **.',True, YELLOW)
        caveW2Rect=caveW2Surf.get_rect()
        caveW2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveW2Surf, caveW2Rect)
        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_c):
                    sharkFish1()  
        pygame.display.update()        
    
def blueStoneWater():
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(waterCave_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF, (150, 320))
        DISPLAYSURF.blit(blueStone_SURF, (350, 620))
        
        caveWFont=pygame.font.Font('freesansbold.ttf', 24)
        caveWSurf=caveWFont.render(
'Ted throws blue stone at the shark and hits him on the head.',True, YELLOW)
        caveWRect=caveWSurf.get_rect()
        caveWRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveWSurf, caveWRect)
        
        caveW2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveW2Surf=caveW2Font.render(
'It looks like the shark has gone ,Ted jumps in the water to swim to the boat.',True, YELLOW)
        caveW2Rect=caveW2Surf.get_rect()
        caveW2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveW2Surf, caveW2Rect)###
        startKeyMes()
        if keyPress():
            pygame.event.get()
            blueStoneUnderSea()        
        pygame.display.update()


def tedBoat():#to boatToCave score 10 points
    global score##score
    score +=10
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(waterCave_SURF, (5, 5))
        DISPLAYSURF.blit(halfTed_SURF, (700, 50))
        
        cavebFont=pygame.font.Font('freesansbold.ttf', 24)
        cavebSurf=cavebFont.render(
'Ted is safely on the boat.',True, YELLOW)
        cavebRect=cavebSurf.get_rect()
        cavebRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(cavebSurf, cavebRect)
        
        caveb2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveb2Surf=cavebFont.render(
'You have scored 10 points .',True, YELLOW)
        caveb2Rect=caveb2Surf.get_rect()
        caveb2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveb2Surf, caveb2Rect)###
        startKeyMes()
        if keyPress():
            pygame.event.get()
            boatToCave()        
        pygame.display.update()         

def sharkFish12():# to ted boat
    DISPLAYSURF.fill(BLACK)
    tedKFont=pygame.font.Font('freesansbold.ttf', 24)
    tedKSurf=tedKFont.render(
'***Ted gets safely to the boat !***.', True, YELLOW)
    tedKRect=tedKSurf.get_rect()
    tedKRect.midtop=(WINDOWWIDTH/2, 750)
    DISPLAYSURF.blit(tedKSurf, tedKRect)
    pleaseWait()
    fallimg=pygame.image.load('fish.png')
    fallx=200
    fally=300
    direction='right'
    while True:
        DISPLAYSURF.blit(madFish_SURF, (5, 5))

        if direction=='right':
            fallx+=5
            if fallx==1400:
                pygame.time.wait(5000)
                pygame.mixer.Sound.stop(underSeaObj)
                tedBoat()               
        DISPLAYSURF.blit(fallimg, (fallx, fally))  #     
        pygame.display.update()        
        FPSCLOCK.tick(FPS)
def glitBallUnderSea():##to sharkFish2##
    while True:
        underSeaObj.play()
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(madFish_SURF, (5, 5))
        DISPLAYSURF.blit(ted2FallR_IMG, (900, 130))
        DISPLAYSURF.blit(glitBall_SURF, (100, 350))
        caveWFont=pygame.font.Font('freesansbold.ttf', 24)
        caveWSurf=caveWFont.render(
'The shark is distracted by the gliter ball .Ted swims for the boat .',True, YELLOW)
        caveWRect=caveWSurf.get_rect()
        caveWRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveWSurf, caveWRect)
        
        caveW2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveW2Surf=caveW2Font.render(
'. ** Press ,  c  , to continue    **.',True, YELLOW)
        caveW2Rect=caveW2Surf.get_rect()
        caveW2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveW2Surf, caveW2Rect)
        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_c):
                    sharkFish12()  
        pygame.display.update()          
    
def gliterBallWater():##to  glitballundersea
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(waterCave_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF, (150, 320))
        DISPLAYSURF.blit(glitBall_SURF, (350, 620))
        
        cavegFont=pygame.font.Font('freesansbold.ttf', 24)
        cavegSurf=cavegFont.render(
'Ted throws the gliter ball at the shark,.',True, YELLOW)
        cavegRect=cavegSurf.get_rect()
        cavegRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(cavegSurf, cavegRect)
        
        caveg2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveg2Surf=caveg2Font.render(
'It looks like the shark has gone ,Ted jumps in the water to swim to the boat.',True, YELLOW)
        caveg2Rect=caveg2Surf.get_rect()
        caveg2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveg2Surf, caveg2Rect)###
        startKeyMes()
        if keyPress():
            pygame.event.get()
            glitBallUnderSea()        
        pygame.display.update()        
def boatToCave():
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF, (400, 350))#ok
        DISPLAYSURF.blit(lottie_SURF, (800, 450))
        
        tunCaveFont=pygame.font.Font('freesansbold.ttf', 24)
        tunCaveSurf=tunCaveFont.render(
'Ted rowed the boat safely across the water to a cave on the other side',True, YELLOW)
        tunCaveRect=tunCaveSurf.get_rect()
        tunCaveRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(tunCaveSurf, tunCaveRect)
        
        tunCave1Font=pygame.font.Font('freesansbold.ttf', 24)
        tunCave1Surf=tunCave1Font.render(
"  Press  ,  e  , To enter the cave",True, YELLOW)
        tunCave1Rect=tunCave1Surf.get_rect()
        tunCave1Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(tunCave1Surf, tunCave1Rect)
        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_e):
                   redTunnelxy()        
        pygame.display.update()      
def waterCave():###total score  score 10 + total score
    seaWavesObj.play()
   
    DISPLAYSURF.fill(BLACK)
    DISPLAYSURF.blit(rope_SURF, (350, 620))
    DISPLAYSURF.blit(glitBall_SURF, (780, 620))
    DISPLAYSURF.blit(blueStone_SURF, (540, 620))

    
    cave2Font=pygame.font.Font('freesansbold.ttf', 24)
    cave2Surf=cave2Font.render(
'The cave is filled with water and a boat out of reach, on the floor are 3 items, you may only pick one.',True,YELLOW)
    cave2Rect=cave2Surf.get_rect()
    cave2Rect.midtop=(WINDOWWIDTH/2, 730)
    DISPLAYSURF.blit(cave2Surf, cave2Rect)
        
    cave22Font=pygame.font.Font('freesansbold.ttf', 24)
    cave22Surf=cave22Font.render(
'Items, *(a) Rope with hook.* (b) blue stone ,heavy *  (c)  Gliter ball heavy */  Press  a,  b,  or  c .',True, YELLOW)
    cave22Rect=cave22Surf.get_rect()
    cave22Rect.midtop=(WINDOWWIDTH/2, 755)
    DISPLAYSURF.blit(cave22Surf, cave22Rect)
        
    cave23Font=pygame.font.Font('freesansbold.ttf', 24)
    cave23Surf=cave23Font.render(
' Goal  *  Get Ted to the boat ,there is a large shark in water ready to eat him.',True, YELLOW)
    cave23Rect=cave23Surf.get_rect()
    cave23Rect.midtop=(WINDOWWIDTH/2, 780)
    DISPLAYSURF.blit(cave23Surf, cave23Rect)  
    
    fallx=300
    fally=400
    direction='right'    
    while True:
        seaWavesObj.play()        
        DISPLAYSURF.blit(waterCave_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF, (150, 320))      
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)
        checkForQuit()
        fallimg=L_FIN_IMG###ok
        if direction == 'right':
            fallx += 2
            if fallx==800:
                direction = 'left'#ok
           
        elif direction == 'left':#ok
            fallimg=R_FIN_IMG   ##ok      
            fallx -= 2
            if fallx == 300:  
                direction = 'right'        
        DISPLAYSURF.blit(fallimg, (fallx, fally))          
        
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_a):
                    pygame.mixer.Sound.stop(seaWavesObj)                     
                    ropeWater1()
                if (event.key==K_b):
                    pygame.mixer.Sound.stop(seaWavesObj)                     
                    blueStoneWater()
                if (event.key==K_c):
                    pygame.mixer.Sound.stop(seaWavesObj)                     
                    gliterBallWater()                   
        pygame.display.update()

def tunnelYchestOpen():###ok   chest  open
    global score
    score -=5
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(noteS_SURF, (520, 400))
        DISPLAYSURF.blit(chestb_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(lottie_SURF, (800, 500))
        tunKeyFont=pygame.font.Font('freesansbold.ttf', 24)
        tunKeySurf=tunKeyFont.render(
"ted breaks the chest open with his crow bar,inside is a note. ",True, YELLOW)
        tunKeyRect=tunKeySurf.get_rect()
        tunKeyRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(tunKeySurf, tunKeyRect)
        
        tunKey2Font=pygame.font.Font('freesansbold.ttf', 24)
        tunKey2Surf=tunKey2Font.render(
"Note reads ,*  You lose 5 points off your score for damageing the chest.",True, YELLOW)
        tunKey2Rect=tunKey2Surf.get_rect()
        tunKey2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(tunKey2Surf, tunKey2Rect) 
        startKeyMes()
        if keyPress():
            pygame.event.get()
            tunnelLR() ###tunnel left right ok   
        pygame.display.update()     

def tunnelYchest():##from cBar##chest closed
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chesta_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(lottie_SURF, (800, 500))
        tunKeyFont=pygame.font.Font('freesansbold.ttf', 24)
        tunKeySurf=tunKeyFont.render(
"In the tunnel Ted finds an old chest. It may contain treasure,it's locked. ",True, YELLOW)
        tunKeyRect=tunKeySurf.get_rect()
        tunKeyRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(tunKeySurf, tunKeyRect)
        
        tunKey2Font=pygame.font.Font('freesansbold.ttf', 24)
        tunKey2Surf=tunKey2Font.render(
"Ted can use his crowbar to forse the chest open. Press  , c ,to open the chest .",True, YELLOW)
        tunKey2Rect=tunKey2Surf.get_rect()
        tunKey2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(tunKey2Surf, tunKey2Rect) 
        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_c):
                    woodCObj.play() 
                    pygame.time.wait(8000)
                    pygame.mixer.Sound.stop(woodCObj)
                    tunnelYchestOpen()#open chest       
        pygame.display.update()
        FPSCLOCK.tick(FPS)        
        
def tedFallRedTun():
    fallx=200
    fally=50
    direction='down'
    while True:
        DISPLAYSURF.blit(redTunXY_SURF, (5, 5))
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)   
        fallimg=ted2Front_SURF###ok
        if direction == 'down':
            fally += 3
        if fally==320:
            redTunnelxy()                        
        DISPLAYSURF.blit(fallimg, (fallx, fally))
        pygame.display.update()
        
def tunnelRight():##down hole to ted fall
    fallimg=ted2Front_SURF
    fallx=800
    fally=100
    direction='right'
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(mineShaft_SURF, (5, 5))       
        tedKFont=pygame.font.Font('freesansbold.ttf', 24)
        tedKSurf=tedKFont.render(
' Ted is chased by the cat down the tunnel and falls down a hole !.', True, YELLOW)
        tedKRect=tedKSurf.get_rect()
        tedKRect.midtop=(WINDOWWIDTH/2, 700)
        DISPLAYSURF.blit(tedKSurf, tedKRect)
    
        tedKFont=pygame.font.Font('freesansbold.ttf', 24)
        tedKSurf=tedKFont.render(
'***He is back at the red tunnel!***.', True, YELLOW)
        tedKRect=tedKSurf.get_rect()
        tedKRect.midtop=(WINDOWWIDTH/2, 750)
        DISPLAYSURF.blit(tedKSurf, tedKRect)
        pleaseWait()
        if direction=='right':
            fallx+=5
            if fallx==810:
                direction='down'
        elif direction=='down':
            fally+=5
            if fally==300:
                pygame.time.wait(7000)                
                tedFallRedTun()               
        DISPLAYSURF.blit(fallimg, (fallx, fally))        
        pygame.display.update()
        FPSCLOCK.tick(FPS)
        
def tunnelLeft():#from tunnelLR LEFT to mine shaft
    fallimg=pygame.image.load('ted2Fall.png')
    fallx=800
    fally=100
    direction='right'
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(mineShaft_SURF, (5, 5))       
        tedKFont=pygame.font.Font('freesansbold.ttf', 24)
        tedKSurf=tedKFont.render(
' Ted is chased by the cat down the tunnel and falls down a mine shaft!.', True, YELLOW)
        tedKRect=tedKSurf.get_rect()
        tedKRect.midtop=(WINDOWWIDTH/2, 700)
        DISPLAYSURF.blit(tedKSurf, tedKRect)
    
        tedKFont=pygame.font.Font('freesansbold.ttf', 24)
        tedKSurf=tedKFont.render(
'***You have killed Ted !***.', True, YELLOW)
        tedKRect=tedKSurf.get_rect()
        tedKRect.midtop=(WINDOWWIDTH/2, 750)
        DISPLAYSURF.blit(tedKSurf, tedKRect)
        pleaseWait()
        if direction=='right':
            fallx+=5
            if fallx==810:
                direction='down'
        elif direction=='down':
            fally+=5
            if fally==200:
                thumpObj.play()
            if fally==500:
                pygame.time.wait(7000)
                pygame.mixer.Sound.stop(thumpObj)
                gameOver()               
        DISPLAYSURF.blit(fallimg, (fallx, fally))        
        pygame.display.update()
        FPSCLOCK.tick(FPS)
        
def tunnelLR():#from blueDoorNote 
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunLR_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF,(200, 400))
        DISPLAYSURF.blit(lottie_SURF, (800, 500))
                
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
'At the end of the tunnel it divides into 2 .  LEFT and RIGHT ',True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'Pick a tunnel,  Press , l, for left , or , r, for right .',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_l):
                    tunnelLeft()
                if (event.key==K_r):
                    tunnelRight()
        pygame.display.update()     

def blueDoorNote():##tunnel x blue door
    global score##score
    score -=5     
    while True:       
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF, (400, 350))
        DISPLAYSURF.blit(cBar_SURF, (800, 400))
        DISPLAYSURF.blit(noteS_SURF, (600, 500))
        
        cavegFont=pygame.font.Font('freesansbold.ttf', 24)
        cavegSurf=cavegFont.render(
'On the floor is a note, it reads,  You lose 5 points for breaking the door.',True, YELLOW)
        cavegRect=cavegSurf.get_rect()
        cavegRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(cavegSurf, cavegRect)
        
        caveg2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveg2Surf=caveg2Font.render("Ted's not happy.",True, YELLOW)
        caveg2Rect=caveg2Surf.get_rect()
        caveg2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveg2Surf, caveg2Rect)
        startKeyMes()
        if keyPress():
            pygame.event.get()
            tunnelLR()        
        pygame.display.update()
        
def tunnelXblueDoor():##from tunnel x and y
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(blueDoor_SURF, (5, 5))
        DISPLAYSURF.blit(cBar_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
'  The blue door is locked ',True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'Ted can use his crowbar to force the door open.  Press,  c , to open the door',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_c):
                    woodCObj.play() 
                    pygame.time.wait(8000)
                    pygame.mixer.Sound.stop(woodCObj)
                    blueDoorNote()
        pygame.display.update()
        FPSCLOCK.tick(FPS)

def cBar():
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(redTunXY_SURF, (5, 5))
        DISPLAYSURF.blit(cBar_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))                
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
'  You have picked the crowbar',True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'Pick a tunnel,  Press , x , or , y .',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_x):##ok
                    tunnelXblueDoor()
                if (event.key==K_y):
                    tunnelYchest()#ok
        pygame.display.update()

        
def blueDoorChestOpen():##to tunnelLR#ok
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(noteS_SURF, (550, 400))
        DISPLAYSURF.blit(catBall_SURF, (650, 400))
        DISPLAYSURF.blit(chestb_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(lottie_SURF, (800, 500))
        tunKeyFont=pygame.font.Font('freesansbold.ttf', 24)
        tunKeySurf=tunKeyFont.render(
"ted opens the chest,inside is a note. ",True, YELLOW)
        tunKeyRect=tunKeySurf.get_rect()
        tunKeyRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(tunKeySurf, tunKeyRect)
        
        tunKey2Font=pygame.font.Font('freesansbold.ttf', 24)
        tunKey2Surf=tunKey2Font.render(
"Note reads ,* No score, but you have found the cat's ball.  *",True, YELLOW)
        tunKey2Rect=tunKey2Surf.get_rect()
        tunKey2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(tunKey2Surf, tunKey2Rect) 
        startKeyMes()
        if keyPress():
            pygame.event.get()
            tunnelLR() ###tunnel left right ok   
        pygame.display.update()     
        
def blueDoorChest():#blueDoorChestOpen##   sound
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chesta_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(lottie_SURF, (800, 500))
        tunKeyFont=pygame.font.Font('freesansbold.ttf', 24)
        tunKeySurf=tunKeyFont.render(
"In the tunnel Ted finds an old chest. It may contain treasure,it's locked. ",True, YELLOW)
        tunKeyRect=tunKeySurf.get_rect()
        tunKeyRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(tunKeySurf, tunKeyRect)
        
        tunKey2Font=pygame.font.Font('freesansbold.ttf', 24)
        tunKey2Surf=tunKey2Font.render(
"Ted can use his key to open the chest.   Press  , k ,to open the chest .",True, YELLOW)
        tunKey2Rect=tunKey2Surf.get_rect()
        tunKey2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(tunKey2Surf, tunKey2Rect) 
        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_k):
                    blueDoorChestOpen()#open chest       
        pygame.display.update()
    
def scoreLost2():
    scorelFont=pygame.font.Font('freesansbold.ttf', 70)
    scorelSurf=scorelFont.render('*Sorry you lost 2 points *', True, BLUE)
    scorelRect = scorelSurf.get_rect()
    scorelRect.midtop =(WINDOWWIDTH /2, 300)
    DISPLAYSURF.blit(scorelSurf, scorelRect)        
       
        
def score10():
    scorebFont=pygame.font.Font('freesansbold.ttf', 70)
    scorebSurf=scorebFont.render('*Score  10  Points*', True, BLUE)
    scorebRect = scorebSurf.get_rect()
    scorebRect.midtop =(WINDOWWIDTH /2, 300)
    DISPLAYSURF.blit(scorebSurf, scorebRect)
    
def scoreNil():
    scorenFont=pygame.font.Font('freesansbold.ttf', 70)
    scorenSurf=scorenFont.render('*Sorry you lost 5 points *', True, BLUE)
    scorenRect = scorenSurf.get_rect()
    scorenRect.midtop =(WINDOWWIDTH /2, 300)
    DISPLAYSURF.blit(scorenSurf, scorenRect)
        
def tresCave(): #clue / ring  / grin
    XTRAN_RECT = pygame.Rect(650, 420, 170, 110) # position x and y , size x  size  y        
    RTRAN_RECT = pygame.Rect(610, 430, 30, 30) # position x and y , size x  size  y
    X2TRAN_RECT = pygame.Rect(600, 470, 50, 50) #pos x and y , size x  size  y
    X3TRAN_RECT = pygame.Rect(320, 430, 70, 100) # pos x and y , size x  size  y    
    
    while True:
        global score
        global tres
        
        pygame.draw.rect(DISPLAYSURF,WHITE, XTRAN_RECT)#white rect under background         
        pygame.draw.rect(DISPLAYSURF,WHITE, RTRAN_RECT)# white rect under background
        pygame.draw.rect(DISPLAYSURF,GREEN, X2TRAN_RECT)#green rect under background
        pygame.draw.rect(DISPLAYSURF,GREEN, X3TRAN_RECT)#green rect under background
        
        DISPLAYSURF.blit(tresCave_SURF, (5, 5))
        DISPLAYSURF.blit(candleA_SURF, (260, 180))
        DISPLAYSURF.blit(bela, (900, 400))
        
        DISPLAYSURF.blit(tresChest_SURF, (500, 220))
        DISPLAYSURF.blit(ted2Front_SURF,(50, 330))
        pygame.display.update()        
        pygame.time.wait(1000)             
        
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
'One item in the treasure cave is worth  10 points . ', True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)
        
        chest2Font=pygame.font.Font('freesansbold.ttf', 24)
        chest2Surf=chest2Font.render(
" Your clue is **  Can be found in a  'grin'   ** ", True, YELLOW)
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)
        
        chest3Font=pygame.font.Font('freesansbold.ttf', 24)
        chest3Surf=chest3Font.render(
'If you click on the other items you will lose  5  points.', True, YELLOW)
        chest3Rect=chest3Surf.get_rect()
        chest3Rect.midtop=(WINDOWWIDTH/2, 790)
        DISPLAYSURF.blit(chest3Surf, chest3Rect)

        DISPLAYSURF.blit(candleB_SURF, (260, 180))
        DISPLAYSURF.blit(flash, (680, 440)) 
        
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and RTRAN_RECT.collidepoint(event. pos):
                score += 10
                score10()
                pygame.display.update()                
                pygame.time.wait(3000)                 
                candy()
            if event.type == MOUSEBUTTONUP and XTRAN_RECT.collidepoint(event. pos):
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                candy()
            if event.type == MOUSEBUTTONUP and X2TRAN_RECT.collidepoint(event. pos):
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                candy()                
            if event.type == MOUSEBUTTONUP and X3TRAN_RECT.collidepoint(event. pos):
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                candy()

        pygame.display.update()        
        pygame.time.wait(1000)  

        pygame.display.update()
        FPSCLOCK.tick(FPS)

def walkRun(): ## walk  away / & angles
    global walk1img, walk2img, backDrop_SURF 
    walk1img=pygame.image.load('tedBackWalk1Small.png').convert()
    walk2img=pygame.image.load('tedBackWalk2Small.png').convert()
    
    backDrop_SURF=pygame.image.load('mouseCaveALarg.png').convert()

    while True:
        FPS=30  
        width = 160  ## size  of  ted
        height = 260
        
        walk1bx=570  # w start  positions
        walk1by=320 #  h
        walk2bx=570  # w 
        walk2by=310  # h  

        direction='up'
        while True:    
            if direction=='up':
                walk1bx += 10 # +> angle to right / - < angle to left / del for strait
                walk1by -= 6  # steps forward
                width -= 2   # size of ted   - smaller / + larger
                height -= 4   # size of ted
                        
                DISPLAYSURF.fill(BLACK)
                DISPLAYSURF.blit(backDrop_SURF, (5, 5))
                ted = pygame.transform.scale(walk1img, (width, height))
                
                DISPLAYSURF.blit(ted, (walk1bx, walk1by))            
                pygame.display.update()            
                pygame.time.wait(300) ##300 for walk //100 for run
    
                walk2by = walk1by  #  steps forward
                walk2bx = walk1bx  # > / < angles
                
                walk1bx += 10 # +> angle to right / - < angle to left / del for strait
                walk2by -= 6  # steps forward              
                width -= 2  # size of ted
                height -= 4   # size
                              
                DISPLAYSURF.fill(BLACK)
                DISPLAYSURF.blit(backDrop_SURF, (5, 5))
                ted2 = pygame.transform.scale(walk2img, (width, height))
                
                DISPLAYSURF.blit(ted2, (walk2bx, walk2by))       
                pygame.display.update()             
                pygame.time.wait(300)  # 300 for walk // 100 for run
                
                walk1by = walk2by  # steps forward
                walk1bx = walk2bx  # > / < angles
                
                if walk1by <= 200:  # end point
                    pygame.time.wait(1000)                
                    tresCave()                 
                if walk2by <= 200:  # end point
                    pygame.time.wait(1000)                   
                    tresCave()                     
    FPSCLOCK.tick(FPS)

        
def keyChestOpen():    
    TRAN_RECT = pygame.Rect(750, 220, 20, 110) #x and y , size x  size  y    
    while True:
        DISPLAYSURF.fill(BLACK)
        pygame.draw.rect(DISPLAYSURF,WHITE, TRAN_RECT)#### white rect under background   ok      
        DISPLAYSURF.blit(mouseCave, (5, 5))
        DISPLAYSURF.blit(noteS_SURF, (550, 400))
        DISPLAYSURF.blit(chestb_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(lottie_SURF, (800, 500))
        DISPLAYSURF.blit(Mouse_SURF, (550, 500))
        mousesObj.play()
        
        tunKeyFont=pygame.font.Font('freesansbold.ttf', 24)
        tunKeySurf=tunKeyFont.render(
"The chest is open,inside is a note. ",True, YELLOW)
        tunKeyRect=tunKeySurf.get_rect()
        tunKeyRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(tunKeySurf, tunKeyRect)
        
        tunKey2Font=pygame.font.Font('freesansbold.ttf', 24)
        tunKey2Surf=tunKey2Font.render(
"Note reads ,*  No score but you have found the cat's mouse.",True, YELLOW)
        tunKey2Rect=tunKey2Surf.get_rect()
        tunKey2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(tunKey2Surf, tunKey2Rect)

        tunKey3Font=pygame.font.Font('freesansbold.ttf', 24)
        tunKey3Surf=tunKey3Font.render(
" You can play with the mouse or press  c  to continue.",True, YELLOW)
        tunKey3Rect=tunKey3Surf.get_rect()
        tunKey3Rect.midtop=(WINDOWWIDTH/2, 790)
        DISPLAYSURF.blit(tunKey3Surf, tunKey3Rect)
        
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and TRAN_RECT.collidepoint(event. pos):
                pygame.mixer.Sound.stop(mousesObj)
                walkRun()
            if event.type == KEYUP:# ok
                if (event.key == K_c):
                    pygame.mixer.Sound.stop(mousesObj)                    
                    tunnelLR()  
        pygame.display.update()          

def tunnelYchestKey():#ok
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(mouseCave, (5, 5))
        DISPLAYSURF.blit(chesta_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(lottie_SURF, (800, 500))        
        tunKeyFont=pygame.font.Font('freesansbold.ttf', 24)
        tunKeySurf=tunKeyFont.render(
"In the tunnel Ted finds an old chest. It may contain treasure,it's locked. ",True, YELLOW)
        tunKeyRect=tunKeySurf.get_rect()
        tunKeyRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(tunKeySurf, tunKeyRect)
        
        tunKey2Font=pygame.font.Font('freesansbold.ttf', 24)
        tunKey2Surf=tunKey2Font.render(
"Ted can use his key to open the chest . Press  , k ,to open the chest .",True, YELLOW)
        tunKey2Rect=tunKey2Surf.get_rect()
        tunKey2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(tunKey2Surf, tunKey2Rect) 
        for event in pygame.event.get():
            if event.type == KEYUP:
                if (event.key==K_k):
                    keyChestOpen()#open chest       
        pygame.display.update()        

def tunnelXblueDoorKey():#to blueDoorChest
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(blueDoor_SURF, (5, 5))
        DISPLAYSURF.blit(key_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
'  The blue door is locked ',True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'Ted can use his key to open the door.  Press,  c , to open the door',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_c):
                    doorObj.play()
                    blueDoorChest()
        pygame.display.update()

def keyTunnelXY():###to tunnelXblueDoorKey and tunnelYchestKey
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(redTunXY_SURF, (5, 5))
        DISPLAYSURF.blit(key_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))                
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
'  You have picked the key',True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'Pick a tunnel,  Press , x , or , y .',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_x):##0k
                    tunnelXblueDoorKey()#okblue door ball
                if (event.key==K_y):
                    tunnelYchestKey()#okred door mouse
        pygame.display.update()
        
def chestOpenTres(): ##score 10  tres 5 Doors 1 back to candyBlueDoorX and ted flip
    DISPLAYSURF.fill(BLACK)
    global score
    score +=12
    global Doors
    Doors +=1
    global tres
    tres += 5
    while True:
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chestb_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(tres_SURF, (600, 400))
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"You have scored 10 points , 5 treasure points and opened a door. ",True, YELLOW)##tunnel and chest open 
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)
        pygame.display.update()
        pygame.time.wait(5000)        
        flip()       #ok
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chestb_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Front_SURF, (400, 350))
        DISPLAYSURF.blit(tres_SURF, (600, 400))
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"      ted's  Happy ",True, YELLOW)##tunnel and chest open 
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)  #ok
        pygame.display.update()
        pygame.time.wait(2000)         
        startKeyMes()
        pygame.display.update()        
        pygame.time.wait(5000)         
        if keyPress():
            pygame.event.get()
            candyBlueDoorX()
        candyBlueDoorX()            
        pygame.display.update() 
        FPSCLOCK.tick(FPS)
        
def puzzleA():
    startTime=0
    startTime=time.time()    
    global Doors
    global score
    while True:
        DISPLAYSURF.fill(BLACK) 
        DISPLAYSURF.blit(blueDoor_SURF, (5, 5))
        DISPLAYSURF.blit(candy_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))      
        doorsSurf=BIGFONT.render('Doors open :' + str(Doors), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
"How many moons does Neptune have ?*",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)       
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'*a, 10 *.  * b 4 *. * c, 6. * * d, 8 *.  Press a , b , c or  d. ',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Doors == 3:
            toRailTun()        
        if time.time() - 40 > startTime:# time
            timeLeft()#ok
            if time.time() -60 > startTime:# time
                score -=2       
                scoreLost2()
                pygame.display.update()                    
                pygame.time.wait(3000)
                candy()               
               
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_d):
                    doorObj.play()#ok
                    chestOpenTres()
                else:
                    score -=2   
                    scoreLost2()
                    pygame.display.update()                    
                    pygame.time.wait(3000)
                    candy()
                    
        pygame.display.update()
        FPSCLOCK.tick(FPS)
        
def puzzleB():
    startTime=0
    startTime=time.time()  
    global Doors
    global score
    while True:
        DISPLAYSURF.fill(BLACK) 
        DISPLAYSURF.blit(blueDoor_SURF, (5, 5))
        DISPLAYSURF.blit(candy_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))      
        doorsSurf=BIGFONT.render('Doors open :' + str(Doors), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
"What is aformosa ?*",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)       
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'*a, town *.  * b,  wood *. * c, country. * * d, flower *.  Press a , b , c or  d. ',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Doors == 3:
            toRailTun()         
        if time.time() - 40 > startTime:
            timeLeft()#ok
            if time.time() -60 > startTime:
                score -=2       
                scoreLost2()
                pygame.display.update()                    
                pygame.time.wait(3000)
                candy()                 
               
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_b):#ok
                    doorObj.play()                    
                    chestOpenTres()
                else:
                    score -=2   
                    scoreLost2()
                    pygame.display.update()                    
                    pygame.time.wait(3000)
                    candy()
                    
        pygame.display.update()
        FPSCLOCK.tick(FPS)                    
    
def puzzleC():###ok
    startTime=0
    startTime=time.time()    
    global Doors
    global score
    while True:
        DISPLAYSURF.fill(BLACK) 
        DISPLAYSURF.blit(blueDoor_SURF, (5, 5))
        DISPLAYSURF.blit(candy_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))      
        doorsSurf=BIGFONT.render('Doors open :' + str(Doors), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
"When was Braille invented?*",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)       
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'*a, 1790 *.  * b 1870 *. * c, 1824. * * d, 1910 *.  Press a , b , c or  d. ',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Doors == 3:
            toRailTun()         
        if time.time() - 40 > startTime:
            timeLeft()#ok
            if time.time() -60 > startTime:
                score -=2       
                scoreLost2()
                pygame.display.update()                    
                pygame.time.wait(3000)
                candy()             
               
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_c):#ok
                    doorObj.play()                    
                    chestOpenTres()
                else:
                    score -=2   
                    scoreLost2()
                    pygame.display.update()                    
                    pygame.time.wait(3000)
                    candy()
                    
        pygame.display.update()
        FPSCLOCK.tick(FPS)  
    
def puzzleD():
    startTime=0
    startTime=time.time()     
    global Doors
    global score
    while True:
        DISPLAYSURF.fill(BLACK) 
        DISPLAYSURF.blit(blueDoor_SURF, (5, 5))
        DISPLAYSURF.blit(candy_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))      
        doorsSurf=BIGFONT.render('Doors open :' + str(Doors), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
"What has the chemical symble  Fe ?*",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)       
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'*a, tin *.  * b copper *. * c, silver. * * d, iron *.  Press a , b , c or  d. ',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Doors == 3:
            toRailTun()         
        if time.time() - 40 > startTime:
            timeLeft()#ok
            if time.time() -60 > startTime:
                score -=2       
                scoreLost2()
                pygame.display.update()                    
                pygame.time.wait(3000)
                candy()   
              
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_d):
                    doorObj.play()#ok
                    chestOpenTres()
                else:
                    score -=2   
                    scoreLost2()
                    pygame.display.update()                    
                    pygame.time.wait(3000)
                    candy()
                    
        pygame.display.update()
        FPSCLOCK.tick(FPS)   
    
def puzzleE():
    startTime=0
    startTime=time.time()    
    global Doors
    global score
    while True:
        DISPLAYSURF.fill(BLACK) 
        DISPLAYSURF.blit(blueDoor_SURF, (5, 5))
        DISPLAYSURF.blit(candy_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))      
        doorsSurf=BIGFONT.render('Doors open :' + str(Doors), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
"What is a unit of electromagnetic induction ?*",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)       
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'*a, Henry *.  * b ,Philip *. * c, Abert. * * d, James *.  Press a , b , c or  d. ',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Doors == 3:
            toRailTun()        
        if time.time() -40 > startTime:
            timeLeft()#ok
            if time.time() -60 > startTime:
                score -=2       
                scoreLost2()
                pygame.display.update()                    
                pygame.time.wait(3000)
                candy()                  
               
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_a):#ok
                    doorObj.play()                    
                    chestOpenTres()
                else:
                    score -=2   
                    scoreLost2()
                    pygame.display.update()                    
                    pygame.time.wait(3000)
                    candy()
                    
        pygame.display.update()
        FPSCLOCK.tick(FPS)  
    
def puzzleF():
    startTime=0
    startTime=time.time()     
    global Doors
    global score
    while True:
        DISPLAYSURF.fill(BLACK) 
        DISPLAYSURF.blit(blueDoor_SURF, (5, 5))
        DISPLAYSURF.blit(candy_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))      
        doorsSurf=BIGFONT.render('Doors open :' + str(Doors), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" What is the diameter of the dial of Big Ben ?*",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)       
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'*a, 21 feet *.  *b, 19 feet  *. *c, 23 feet .* *d, 26 feet,  *.  Press a , b , c or  d. ',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Doors == 3:
            toRailTun()        
        if time.time() - 40 > startTime:
            timeLeft()#ok
            if time.time() -60 > startTime:
                score -=2       
                scoreLost2()
                pygame.display.update()                    
                pygame.time.wait(3000)
                candy()                    
               
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_c):#ok
                    doorObj.play()                    
                    chestOpenTres()
                else:
                    score -=2   
                    scoreLost2()
                    pygame.display.update()                    
                    pygame.time.wait(3000)
                    candy()
                    
        pygame.display.update()
        FPSCLOCK.tick(FPS)  


def puzzlesAtoF():## random X tunnel
    while True:
        if random.randint(1, 6) == 1:
            puzzleA()
        if random.randint(1, 6) == 2:
            puzzleB()
        if random.randint(1, 6) == 3:
            puzzleC()
        if random.randint(1, 6) == 4:
            puzzleD()
        if random.randint(1, 6) == 5:
            puzzleE()
        if random.randint(1, 6) == 6:
            puzzleF()
        
def candyBlueDoorX():##ok
    global score
    global Doors
    DISPLAYSURF.fill(BLACK) 
    DISPLAYSURF.blit(blueDoor_SURF, (5, 5))
    DISPLAYSURF.blit(candy_SURF, (350, 600))
    DISPLAYSURF.blit(ted2Front_SURF,(100, 330))
    while True:     
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)    
       
        doorsSurf=BIGFONT.render('Doors open :' + str(Doors), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
"  The blue door's are locked to open the door's , solve 3 puzzles",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'*You have 60 seconds to solve each puzzle .If your wrong you lose  2  points.* ',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        startKeyMes()              
        if keyPress():
            pygame.event.get()                
            puzzlesAtoF()
        
        pygame.display.update()
        
def redChestOpenTres():####back to candyRedDoorY and ted flip
    DISPLAYSURF.fill(BLACK)
    global score
    score +=12
    global Doors
    Doors +=1
    global tres
    tres += 5
    while True:
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chestb_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(tres_SURF, (600, 400))
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"You have scored 10 points , 5 treasure points and opened a door. ",True, YELLOW)##hest open 
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)
        pygame.display.update()
        pygame.time.wait(5000)        
        flip()                     #ok
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chestb_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Front_SURF, (400, 350))
        DISPLAYSURF.blit(tres_SURF, (600, 400))
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"      Ted's  Happy ",True, YELLOW)##tunnel and chest open 
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)  #ok 
        pygame.display.update()
        pygame.time.wait(2000)         
        startKeyMes()
        if keyPress():
            pygame.event.get()
            candyRedDoorY()
        candyRedDoorY()            
        pygame.display.update() 
    
def redPuzzleA():###redPuzzles A  ot  F and  random
    startTime=0#
    startTime=time.time() #    
    global Doors
    global score
    while True:
        DISPLAYSURF.fill(BLACK) 
        DISPLAYSURF.blit(redDoor_SURF, (5, 5))
        DISPLAYSURF.blit(sockPuzB_SURF, (300, 10))
        DISPLAYSURF.blit(candy_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))      
        doorsSurf=BIGFONT.render('Doors open :' + str(Doors), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" Which one of the six socks on the right is the same as the sock on the left. *",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)       
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'*  To match the sock.  *.  Press a , b , c ,  d  , e  or  f. ',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Doors == 3:
            toRailTun()        
        if time.time() - 40 > startTime:
            timeLeft()#ok
            if time.time() -60 > startTime:
                score -=2       
                scoreLost2()
                pygame.display.update()                    
                pygame.time.wait(3000)
                candy()                
               
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_b):
                    doorObj.play()
                    redChestOpenTres()
                else:
                    score -=2   
                    scoreLost2()
                    pygame.display.update()                    
                    pygame.time.wait(3000)
                    candy()
                    
        pygame.display.update()
        FPSCLOCK.tick(FPS) 
def redPuzzleB():
    startTime=0
    startTime=time.time()     
    global Doors
    global score
    while True:
        DISPLAYSURF.fill(BLACK) 
        DISPLAYSURF.blit(redDoor_SURF, (5, 5))
        DISPLAYSURF.blit(keyPuzE_SURF, (300, 10))
        DISPLAYSURF.blit(candy_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))      
        doorsSurf=BIGFONT.render('Doors open :' + str(Doors), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" Which one of the six key's on the right is the same as the key on the left. *",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)       
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'*  To match the key.  *.  Press a , b , c , d , e or f ',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Doors == 3:
            toRailTun()         
        if time.time() - 40 > startTime:
            timeLeft()#ok
            if time.time() -60 > startTime:
                score -=2       
                scoreLost2()
                pygame.display.update()                    
                pygame.time.wait(3000)
                candy()               
               
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_e):
                    doorObj.play()
                    redChestOpenTres()
                else:
                    score -=2   
                    scoreLost2()
                    pygame.display.update()                    
                    pygame.time.wait(3000)
                    candy()
                    
        pygame.display.update()
        FPSCLOCK.tick(FPS) 

def redPuzzleC():###ok
    startTime=0#
    startTime=time.time()    
    global Doors
    global score
    while True:
        DISPLAYSURF.fill(BLACK) 
        DISPLAYSURF.blit(redDoor_SURF, (5, 5))
        DISPLAYSURF.blit(tilePuzE_SURF, (300, 10))
        DISPLAYSURF.blit(candy_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))      
        doorsSurf=BIGFONT.render('Doors open :' + str(Doors), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" Which one of the six tiles on the right is the same as the tile on the left. *",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)       
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'*  To match the tile  *.  Press a , b , c , d,  e or  f . '  ,True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Doors == 3:
            toRailTun()#         
        if time.time() - 40 > startTime:
            timeLeft()#ok
            if time.time() -60 > startTime:
                score -=2       
                scoreLost2()
                pygame.display.update()                    
                pygame.time.wait(3000)
                candy()                    
               
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_e):
                    doorObj.play()
                    redChestOpenTres()
                else:
                    score -=2   
                    scoreLost2()
                    pygame.display.update()                    
                    pygame.time.wait(3000)
                    candy()
                    
        pygame.display.update()
        FPSCLOCK.tick(FPS)
        
def redPuzzleD():#b  ok
    startTime=0#
    startTime=time.time() #    
    global Doors
    global score
    DISPLAYSURF.fill(BLACK) 
    DISPLAYSURF.blit(candy_SURF, (350, 600))
    caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
    caveBLSurf=caveBLFont.render(
" Ted,s been eating the magic mushroom's again",True, YELLOW)
    caveBLRect=caveBLSurf.get_rect()
    caveBLRect.midtop=(WINDOWWIDTH/2, 730)
    DISPLAYSURF.blit(caveBLSurf, caveBLRect)       
    caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
    caveBL2Surf=caveBL2Font.render(
'Which one of the four mushrooms is edible *.  Press a , b , c or  d,  *    '  ,True, YELLOW)
    caveBL2Rect=caveBL2Surf.get_rect()
    caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
    DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
    fallimg=tedFloat_IMG    
    fallx=50
    fally=200
    direction='right'
    
    while True:
        DISPLAYSURF.blit(redDoor_SURF, (5, 5))
        DISPLAYSURF.blit(mushPuz_SURF, (300, 10))
          
        doorsSurf=BIGFONT.render('Doors open :' + str(Doors), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)        

        if direction == 'right':
            fallx += 1
            if fallx == 500:
                direction = 'down'
           
        elif direction == 'down':     
            fally += 1
            if fally == 400:                
                direction = 'left'
                
        elif direction=='left':
            fallx -= 1
            if fallx == 50:
                direction = 'up'

        elif direction == 'up':
            fally -= 1
            if fally == 200:
                direction = 'right'                        
        DISPLAYSURF.blit(fallimg, (fallx, fally))          
        
        if Doors == 3:
            toRailTun()#         
        if time.time() - 40 > startTime:
            timeLeft()#ok
            if time.time() -60 > startTime:
                score -=2       
                scoreLost2()
                pygame.display.update()                    
                pygame.time.wait(3000)
                candy()                      
               
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_b):
                    doorObj.play()
                    redChestOpenTres()
                else:
                    score -=2   
                    scoreLost2()
                    pygame.display.update()                    
                    pygame.time.wait(3000)
                    candy()
                    
        pygame.display.update()
        FPSCLOCK.tick(FPS)  

def redPuzzleE():##ok
    startTime=0#
    startTime=time.time() #    
    global Doors
    global score
    while True:
        DISPLAYSURF.fill(BLACK) 
        DISPLAYSURF.blit(redDoor_SURF, (5, 5))
        DISPLAYSURF.blit(jugsPuzF_SURF, (300, 10))
        DISPLAYSURF.blit(candy_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))      
        doorsSurf=BIGFONT.render('Doors open :' + str(Doors), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" Which one of the six jugs on the right is the same as the jug on the left. *",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)       
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'*  To match the jug  *.  Press a , b , c , d,  e or  f . '  ,True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Doors == 3:
            toRailTun()#         
        if time.time() - 40 > startTime:
            timeLeft()#ok
            if time.time() -60 > startTime:
                score -=2       
                scoreLost2()
                pygame.display.update()                    
                pygame.time.wait(3000)
                candy()                   
               
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_f):
                    doorObj.play()#ok
                    redChestOpenTres()
                else:
                    score -=2   
                    scoreLost2()
                    pygame.display.update()                    
                    pygame.time.wait(3000)
                    candy()
                    
        pygame.display.update()
        FPSCLOCK.tick(FPS) 
        
def redPuzzleF():##ok
    startTime=0#
    startTime=time.time() #    
    global Doors
    global score
    while True:
        DISPLAYSURF.fill(BLACK) 
        DISPLAYSURF.blit(redDoor_SURF, (5, 5))
        DISPLAYSURF.blit(butFlyB_SURF, (300, 10))
        DISPLAYSURF.blit(candy_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))      
        doorsSurf=BIGFONT.render('Doors open :' + str(Doors), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" Who's the daddy .Match the caterpillar with the butterfly. *",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)       
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'Which one of the caterpillars on the right belongs to the butterfly *.  Press a , b , c or d. '  ,True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Doors == 3:
            toRailTun()        
        if time.time() - 40 > startTime:
            timeLeft()#ok
            if time.time() -60 > startTime:
                score -=2       
                scoreLost2()
                pygame.display.update()                    
                pygame.time.wait(3000)
                candy()                    
               
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_b):
                    doorObj.play()#ok                    
                    redChestOpenTres()
                else:
                    score -=2   
                    scoreLost2()
                    pygame.display.update()                    
                    pygame.time.wait(3000)
                    candy()
                    
        pygame.display.update()
        FPSCLOCK.tick(FPS)  

def redPuzzlesAtoF():
    while True:
        if random.randint(1, 6) == 1:
            redPuzzleA()
        if random.randint(1, 6) == 2:
            redPuzzleB()
        if random.randint(1, 6) == 3:
            redPuzzleC()
        if random.randint(1, 6) == 4:
            redPuzzleD()
        if random.randint(1, 6) == 5:
            redPuzzleE()
        if random.randint(1, 6) == 6:
            redPuzzleF()        
    
def candyRedDoorY():
    global score
    global tres
    global Doors
    DISPLAYSURF.fill(BLACK) 
    DISPLAYSURF.blit(redDoor_SURF, (5, 5))
    DISPLAYSURF.blit(candy_SURF, (350, 600))
    DISPLAYSURF.blit(ted2Front_SURF,(100, 330))
    while True:     
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)    
       
        doorsSurf=BIGFONT.render('Doors open :' + str(Doors), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
"  The red door's are locked to open the door's , solve 3 puzzles",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'*You have 60 seconds to solve each puzzle .If your wrong you lose  2 points.* ',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        startKeyMes()              
        if keyPress():
            pygame.event.get()                
            redPuzzlesAtoF()
        pygame.display.update()    
        
def candy():
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(redTunXY_SURF, (5, 5))
        DISPLAYSURF.blit(candy_SURF, (350, 600))
        DISPLAYSURF.blit(ted2Front_SURF,(100, 330))                
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
'** Ted loves candy **',True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
' * Pick a tunnel,  Press , x , or , y . *',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_x):##ok
                    candyBlueDoorX()
                if (event.key==K_y):
                    candyRedDoorY()#ok
        pygame.display.update()
        
Puzzles = 0
        
def score20():  #keep
    scorebFont=pygame.font.Font('freesansbold.ttf', 70)
    scorebSurf=scorebFont.render('*Score  20  Points*', True, BLUE)
    scorebRect = scorebSurf.get_rect()
    scorebRect.midtop =(WINDOWWIDTH /2, 300)
    DISPLAYSURF.blit(scorebSurf, scorebRect)
        
def puzMesC():  #keep
    scorebFont=pygame.font.Font('freesansbold.ttf', 70)
    scorebSurf=scorebFont.render('* Puzzle  Book *', True, BLUE)
    scorebRect = scorebSurf.get_rect()
    scorebRect.midtop =(WINDOWWIDTH /2, 300)
    DISPLAYSURF.blit(scorebSurf, scorebRect)     
    
def puzChestOpenTres():      ## ok
    DISPLAYSURF.fill(BLACK)
    global score
    score += 20
    global Puzzles
    Puzzles += 1
    global tres
    tres += 5
    while True:
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chestb_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Side_SURF, (400, 350))
        DISPLAYSURF.blit(tres_SURF, (600, 400))
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"You have scored 20 points , 5 treasure points . ",True, YELLOW)##hest open 
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)
        pygame.display.update()
        pygame.time.wait(5000)        
        flip()                     #ok
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(chestb_SURF, (600, 500))
        DISPLAYSURF.blit(ted2Front_SURF, (400, 350))
        DISPLAYSURF.blit(tres_SURF, (600, 400))
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"      Ted's  Happy ",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)  #ok 
        pygame.display.update()
        pygame.time.wait(2000)
        book()
            
        pygame.display.update() 
        FPSCLOCK.tick(FPS)


  
def bookPuzII():##ok  
    XELPaTRAN_RECT = pygame.Rect(320, 200, 80, 50) # position x and y , size x  size  y 250
    XELPpTRAN_RECT = pygame.Rect(320, 260, 80, 50) #pos x and y , size x  size  y
    XELPzaiTRAN_RECT = pygame.Rect(320, 330, 80, 160) # pos x and y , size x  size  y         
    xelp=pygame.image.load('OPZAIpuz.png').convert()   
    startTime=0#
    startTime=time.time() #    
    global Puzzles
    global score
    while True:
        pygame.draw.rect(DISPLAYSURF,WHITE, XELPaTRAN_RECT)# white rect under background
        pygame.draw.rect(DISPLAYSURF,GREEN, XELPpTRAN_RECT)#green rect under background
        pygame.draw.rect(DISPLAYSURF,WHITE, XELPzaiTRAN_RECT)#green rect under background        
        DISPLAYSURF.fill(BLACK) ##
        DISPLAYSURF.blit(bookOpen, (40, 5))##
        DISPLAYSURF.blit(xelp, (5, 30))    
          
        puzSurf=BIGFONT.render('Puzzles Solved :' + str(Puzzles), True, PYELLOW)#ok
        puzRect=puzSurf.get_rect()
        puzRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(puzSurf, puzRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" You have to solve 3 puzzles in the *PUZZLE BOOK* *",True, YELLOW) 
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'20 points for each puzzle ,get one wrong lose 5 points. '  ,True, YELLOW)  
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Puzzles == 3:
            railTunTicket()      
        if time.time() - 40 > startTime:
            timeLeft()
            if time.time() -60 > startTime:  
                score -= 5
                book()#ok    
        
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and XELPpTRAN_RECT.collidepoint(event. pos):#ok
                score20()
                pygame.display.update()                
                pygame.time.wait(3000)                 
                puzChestOpenTres()  ##for score              
            if event.type == MOUSEBUTTONUP and XELPaTRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()
            if event.type == MOUSEBUTTONUP and XELPzaiTRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()                  

        pygame.display.update()
  
def bookPuzJJ():##ok  
    NUMabcTRAN_RECT = pygame.Rect(280, 200, 170, 140) # position x and y , size x  size  y 250
    NUMdTRAN_RECT = pygame.Rect(280, 340, 170, 40) #pos x and y , size x  size  y
    NUMeTRAN_RECT = pygame.Rect(280, 390, 170, 40) # pos x and y , size x  size  y         
    number=pygame.image.load('numberPuz.png').convert()   
    startTime=0#
    startTime=time.time() #    
    global Puzzles
    global score
    while True:
        pygame.draw.rect(DISPLAYSURF,WHITE, NUMabcTRAN_RECT)# white rect under background
        pygame.draw.rect(DISPLAYSURF,GREEN, NUMdTRAN_RECT)#green rect under background
        pygame.draw.rect(DISPLAYSURF,WHITE, NUMeTRAN_RECT)#green rect under background        
        DISPLAYSURF.fill(BLACK) ##
        DISPLAYSURF.blit(bookOpen, (40, 5))##
        DISPLAYSURF.blit(number, (5, 30))    
          
        puzSurf=BIGFONT.render('Puzzles Solved :' + str(Puzzles), True, PYELLOW)#ok
        puzRect=puzSurf.get_rect()
        puzRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(puzSurf, puzRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" You have to solve 3 puzzles in the *PUZZLE BOOK* *",True, YELLOW) 
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'20 points for each puzzle ,get one wrong lose 5 points. '  ,True, YELLOW)  
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Puzzles == 3:
            railTunTicket()  #            toRailTun()      
        if time.time() - 40 > startTime:
            timeLeft()
            if time.time() -60 > startTime:  
                score -= 5
                book()#ok    
        
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and NUMdTRAN_RECT.collidepoint(event. pos):#ok
                score20()
                pygame.display.update()                
                pygame.time.wait(3000)                 
                puzChestOpenTres()  ##for score              
            if event.type == MOUSEBUTTONUP and NUMabcTRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()
            if event.type == MOUSEBUTTONUP and NUMeTRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()                  

        pygame.display.update()

        
def bookPuzHH():##ok
    PATTERNaTRAN_RECT = pygame.Rect(290, 160, 90, 80) #pos x and y , size x  size  y
    PATTERNbcdTRAN_RECT = pygame.Rect(280, 240, 190, 250) # pos x and y , size x  size  y         
    pattern=pygame.image.load('patternPuz.png').convert()   
    startTime=0#
    startTime=time.time() #    
    global Puzzles
    global score
    while True:
        pygame.draw.rect(DISPLAYSURF,GREEN, PATTERNaTRAN_RECT)#green rect under background
        pygame.draw.rect(DISPLAYSURF,WHITE, PATTERNbcdTRAN_RECT)#green rect under background        
        DISPLAYSURF.fill(BLACK) ##
        DISPLAYSURF.blit(bookOpen, (40, 5))##
        DISPLAYSURF.blit(pattern, (5, 30))    
          
        puzSurf=BIGFONT.render('Puzzles Solved :' + str(Puzzles), True, PYELLOW)#ok
        puzRect=puzSurf.get_rect()
        puzRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(puzSurf, puzRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" You have to solve 3 puzzles in the *PUZZLE BOOK* *",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'20 points for each puzzle ,get one wrong lose 5 points. '  ,True, YELLOW)  
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Puzzles == 3:
            railTunTicket()  #            toRailTun()      
        if time.time() - 40 > startTime:
            timeLeft()
            if time.time() -60 > startTime:  
                score -= 5
                book()#ok    
        
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and PATTERNaTRAN_RECT.collidepoint(event. pos):#ok
                score20()
                pygame.display.update()                
                pygame.time.wait(3000)                 
                puzChestOpenTres()  ##for score              
            if event.type == MOUSEBUTTONUP and PATTERNbcdTRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()                

        pygame.display.update()

        
def bookPuzGG():##ok
    METALbrTRAN_RECT = pygame.Rect(300, 180, 160, 50) #pos x and y , size x  size  y
    METALtilcTRAN_RECT = pygame.Rect(280, 240, 170, 240) # pos x and y , size x  size  y         
    metal=pygame.image.load('metalPuz.png').convert()   
    startTime=0#
    startTime=time.time() #    
    global Puzzles
    global score
    while True:
        pygame.draw.rect(DISPLAYSURF,GREEN, METALbrTRAN_RECT)#green rect under background
        pygame.draw.rect(DISPLAYSURF,WHITE, METALtilcTRAN_RECT)#green rect under background        
        DISPLAYSURF.fill(BLACK) ##
        DISPLAYSURF.blit(bookOpen, (40, 5))##
        DISPLAYSURF.blit(metal, (5, 30))    
          
        puzSurf=BIGFONT.render('Puzzles Solved :' + str(Puzzles), True, PYELLOW)#ok
        puzRect=puzSurf.get_rect()
        puzRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(puzSurf, puzRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" You have to solve 3 puzzles in the *PUZZLE BOOK* *",True, YELLOW) 
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'20 points for each puzzle ,get one wrong lose 5 points. '  ,True, YELLOW)  
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Puzzles == 3:
            railTunTicket()  #            toRailTun()      
        if time.time() - 40 > startTime:
            timeLeft()
            if time.time() -60 > startTime:  
                score -= 5
                book()#ok    
        
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and METALbrTRAN_RECT.collidepoint(event. pos):#ok
                score20()
                pygame.display.update()                
                pygame.time.wait(3000)                 
                puzChestOpenTres()  ##for score              
            if event.type == MOUSEBUTTONUP and METALtilcTRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()                

        pygame.display.update()

  
def bookPuzFF():##ok
    LIVEabTRAN_RECT = pygame.Rect(300, 220, 110, 80) # position x and y , size x  size  y 250
    LIVEcTRAN_RECT = pygame.Rect(300, 310, 110, 40) #pos x and y , size x  size  y
    LIVEdeTRAN_RECT = pygame.Rect(300, 360, 110, 100) # pos x and y , size x  size  y         
    LIVE=pygame.image.load('liveEvilPuz.png').convert()   
    startTime=0#
    startTime=time.time() #    
    global Puzzles
    global score
    while True:
        pygame.draw.rect(DISPLAYSURF,WHITE, LIVEabTRAN_RECT)# white rect under background
        pygame.draw.rect(DISPLAYSURF,GREEN, LIVEcTRAN_RECT)#green rect under background
        pygame.draw.rect(DISPLAYSURF,WHITE, LIVEdeTRAN_RECT)#green rect under background        
        DISPLAYSURF.fill(BLACK) ##
        DISPLAYSURF.blit(bookOpen, (40, 5))##
        DISPLAYSURF.blit(LIVE, (5, 30))    
          
        puzSurf=BIGFONT.render('Puzzles Solved :' + str(Puzzles), True, PYELLOW)#ok
        puzRect=puzSurf.get_rect()
        puzRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(puzSurf, puzRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" You have to solve 3 puzzles in the *PUZZLE BOOK* *",True, YELLOW) 
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'20 points for each puzzle ,get one wrong lose 5 points. '  ,True, YELLOW)  
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Puzzles == 3:
            railTunTicket()       
        if time.time() - 40 > startTime:
            timeLeft()
            if time.time() -60 > startTime:  
                score -= 5
                book()#ok    
        
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and LIVEcTRAN_RECT.collidepoint(event. pos):#ok
                score20()
                pygame.display.update()                
                pygame.time.wait(3000)                 
                puzChestOpenTres()  ##for score              
            if event.type == MOUSEBUTTONUP and LIVEabTRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()
            if event.type == MOUSEBUTTONUP and LIVEdeTRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()                  

        pygame.display.update()

 
def bookPuzEE():##ok
    DESIGNabcTRAN_RECT = pygame.Rect(270, 180, 190, 50) # position x and y , size x  size  y 250
    DESIGNdTRAN_RECT = pygame.Rect(270, 230, 190, 65) #pos x and y , size x  size  y
    DESIGNeTRAN_RECT = pygame.Rect(270, 300, 190, 210) # pos x and y , size x  size  y         
    designe=pygame.image.load('designsPuz.png').convert()   
    startTime=0#
    startTime=time.time() #    
    global Puzzles
    global score
    while True:
        pygame.draw.rect(DISPLAYSURF,WHITE, DESIGNabcTRAN_RECT)# white rect under background
        pygame.draw.rect(DISPLAYSURF,GREEN, DESIGNdTRAN_RECT)#green rect under background
        pygame.draw.rect(DISPLAYSURF,WHITE, DESIGNeTRAN_RECT)#green rect under background        
        DISPLAYSURF.fill(BLACK) ##
        DISPLAYSURF.blit(bookOpen, (40, 5))
        DISPLAYSURF.blit(designe, (5, 30))          
        puzSurf=BIGFONT.render('Puzzles Solved :' + str(Puzzles), True, PYELLOW)#ok
        puzRect=puzSurf.get_rect()
        puzRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(puzSurf, puzRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" You have to solve 3 puzzles in the *PUZZLE BOOK* *",True, YELLOW) 
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'20 points for each puzzle ,get one wrong lose 5 points. '  ,True, YELLOW)  
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Puzzles == 3:
            railTunTicket()  #            toRailTun()      
        if time.time() - 40 > startTime:
            timeLeft()
            if time.time() -60 > startTime:  
                score -= 5
                book()#ok    
        
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and DESIGNdTRAN_RECT.collidepoint(event. pos):#ok
                score20()
                pygame.display.update()                
                pygame.time.wait(3000)                 
                puzChestOpenTres()  ##for score              
            if event.type == MOUSEBUTTONUP and DESIGNabcTRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()
            if event.type == MOUSEBUTTONUP and DESIGNeTRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()                  

        pygame.display.update()

  
def bookPuzDD():##ok
    A123TRAN_RECT = pygame.Rect(300, 200, 160, 190) # position x and y , size x  size  y 250
    A4TRAN_RECT = pygame.Rect(290, 385, 80, 70) #pos x and y , size x  size  y
    A5TRAN_RECT = pygame.Rect(360, 460, 100, 70) # pos x and y , size x  size  y         
    circles=pygame.image.load('circlePuz.png').convert()   
    startTime=0#
    startTime=time.time() #    
    global Puzzles
    global score
    while True:
        pygame.draw.rect(DISPLAYSURF,WHITE, A123TRAN_RECT)# white rect under background
        pygame.draw.rect(DISPLAYSURF,GREEN, A4TRAN_RECT)#green rect under background
        pygame.draw.rect(DISPLAYSURF,WHITE, A5TRAN_RECT)#green rect under background        
        DISPLAYSURF.fill(BLACK) ##
        DISPLAYSURF.blit(bookOpen, (40, 5))##
        DISPLAYSURF.blit(circles, (5, 30))    
          
        puzSurf=BIGFONT.render('Puzzles Solved :' + str(Puzzles), True, PYELLOW)#ok
        puzRect=puzSurf.get_rect()
        puzRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(puzSurf, puzRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" You have to solve 3 puzzles in the *PUZZLE BOOK* *",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'20 points for each puzzle ,get one wrong lose 5 points. '  ,True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Puzzles == 3:
            railTunTicket()       
        if time.time() - 40 > startTime:
            timeLeft()
            if time.time() -60 > startTime:  
                score -= 5
                book()#ok    
        
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and A4TRAN_RECT.collidepoint(event. pos):#ok
                score20()
                pygame.display.update()                
                pygame.time.wait(3000)                 
                puzChestOpenTres()  ##for score              
            if event.type == MOUSEBUTTONUP and A123TRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()
            if event.type == MOUSEBUTTONUP and A5TRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()                  

        pygame.display.update()

  
def bookPuzCC():##ok
    ATRAN_RECT = pygame.Rect(320, 180, 140, 50) # position x and y , size x  size  y 250
    ZFNETRAN_RECT = pygame.Rect(320, 230, 140, 250) # pos x and y , size x  size  y         
    a1e6d4=pygame.image.load('AZFNEpuz.png').convert()   
    startTime=0#
    startTime=time.time() #    
    global Puzzles
    global score
    while True:
        pygame.draw.rect(DISPLAYSURF,WHITE, ATRAN_RECT)# white rect under background
        pygame.draw.rect(DISPLAYSURF,WHITE, ZFNETRAN_RECT)#white rect under background        
        DISPLAYSURF.fill(BLACK) ##
        DISPLAYSURF.blit(bookOpen, (40, 5))##
        DISPLAYSURF.blit(a1e6d4, (5, 30))    
          
        puzSurf=BIGFONT.render('Puzzles Solved :' + str(Puzzles), True, PYELLOW)#ok
        puzRect=puzSurf.get_rect()
        puzRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(puzSurf, puzRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" You have to solve 3 puzzles in the *PUZZLE BOOK* *",True, YELLOW) 
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'20 points for each puzzle ,get one wrong lose 5 points. '  ,True, YELLOW)  
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Puzzles == 3:
            railTunTicket()       
        if time.time() - 40 > startTime:
            timeLeft()
            if time.time() -60 > startTime:  
                score -= 5
                book()#ok    
        
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and ATRAN_RECT.collidepoint(event. pos):#ok
                score20()
                pygame.display.update()                
                pygame.time.wait(3000)                 
                puzChestOpenTres()  ##for score              
            if event.type == MOUSEBUTTONUP and ZFNETRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()                 

        pygame.display.update()

   
def bookPuzBB():##ok
    ADGTRAN_RECT =  pygame.Rect(300, 180, 80, 100) # position x and y , size x  size  y // 300
    ITRAN_RECT =    pygame.Rect(300, 280, 80, 35) #pos x and y , size x  size  y
    JMPSTRAN_RECT = pygame.Rect(300, 325, 80, 150) # pos x and y , size x  size  y         
    abgij=pygame.image.load('abgijmpsPuz.png').convert()   
    startTime=0#
    startTime=time.time() #    
    global Puzzles
    global score
    while True:
        pygame.draw.rect(DISPLAYSURF,WHITE, ADGTRAN_RECT)# white rect under background
        pygame.draw.rect(DISPLAYSURF,GREEN, ITRAN_RECT)#green rect under background
        pygame.draw.rect(DISPLAYSURF,WHITE, JMPSTRAN_RECT)#green rect under background        
        DISPLAYSURF.fill(BLACK) ##
        DISPLAYSURF.blit(bookOpen, (40, 5))##
        DISPLAYSURF.blit(abgij, (5, 30))    
          
        puzSurf=BIGFONT.render('Puzzles Solved :' + str(Puzzles), True, PYELLOW)#ok
        puzRect=puzSurf.get_rect()
        puzRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(puzSurf, puzRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" You have to solve 3 puzzles in the *PUZZLE BOOK* *",True, YELLOW) 
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'20 points for each puzzle ,get one wrong lose 5 points. '  ,True, YELLOW)  
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Puzzles == 3:
            railTunTicket()        
        if time.time() - 40 > startTime:
            timeLeft()
            if time.time() -60 > startTime:  
                score -= 5
                book()#ok    
        
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and ITRAN_RECT.collidepoint(event. pos):#ok
                score20()
                pygame.display.update()                
                pygame.time.wait(3000)                 
                puzChestOpenTres()  ##for score              
            if event.type == MOUSEBUTTONUP and ADGTRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()
            if event.type == MOUSEBUTTONUP and JMPSTRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()                  

        pygame.display.update()
  
def bookPuzAA():##ok
    A1TRAN_RECT = pygame.Rect(300, 180, 110, 50) # position x and y , size x  size  y 250
    E6TRAN_RECT = pygame.Rect(300, 235, 110, 50) #pos x and y , size x  size  y
    C3TRAN_RECT = pygame.Rect(300, 290, 110, 200) # pos x and y , size x  size  y         
    a1e6d4=pygame.image.load('a1e6d4b2c3Puz.png').convert()   
    startTime=0#
    startTime=time.time() #    
    global Puzzles
    global score
    while True:
        pygame.draw.rect(DISPLAYSURF,WHITE, A1TRAN_RECT)# white rect under background
        pygame.draw.rect(DISPLAYSURF,GREEN, E6TRAN_RECT)#green rect under background
        pygame.draw.rect(DISPLAYSURF,WHITE, C3TRAN_RECT)#green rect under background        
        DISPLAYSURF.fill(BLACK) ##
        DISPLAYSURF.blit(bookOpen, (40, 5))
        DISPLAYSURF.blit(a1e6d4, (5, 30))    
          
        puzSurf=BIGFONT.render('Puzzles Solved :' + str(Puzzles), True, PYELLOW)#ok
        puzRect=puzSurf.get_rect()
        puzRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(puzSurf, puzRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" You have to solve 3 puzzles in the *PUZZLE BOOK* *",True, YELLOW) 
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'20 points for each puzzle ,get one wrong lose 5 points. '  ,True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        if Puzzles == 3:
            railTunTicket()  #            toRailTun()      
        if time.time() - 40 > startTime:
            timeLeft()
            if time.time() -60 > startTime:  
                score -= 5
                book()#ok    
        
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and E6TRAN_RECT.collidepoint(event. pos):#ok
                score20()
                pygame.display.update()                
                pygame.time.wait(3000)                 
                puzChestOpenTres()  ##for score              
            if event.type == MOUSEBUTTONUP and A1TRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()
            if event.type == MOUSEBUTTONUP and C3TRAN_RECT.collidepoint(event. pos):#ok
                score -= 5
                scoreNil()
                pygame.display.update()
                pygame.time.wait(3000)
                book()                  

        pygame.display.update()
                                
def book():##  OK
    startTime=0#ok
    startTime=time.time() #ok      
    global Puzzles
    DISPLAYSURF.fill(BLACK)
    while True:
        DISPLAYSURF.blit(bookOpen, (30, 5))
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)    
       
        doorsSurf=BIGFONT.render('Puzzles  Solved  :' + str(Puzzles), True, PYELLOW)#ok
        doorsRect=doorsSurf.get_rect()
        doorsRect.topleft=(WINDOWWIDTH-1200, 20)
        DISPLAYSURF.blit(doorsSurf, doorsRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
" * PUZZLE BOOK * . Solve 3 puzzles",True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'*You have 60 seconds to solve each puzzle* ',True, YELLOW) #ok
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        startKeyMes()
        if time.time() - 15 > startTime:
            bookPuzAAtoJJ()                      
            pygame.display.update()
               
        if keyPress():
            pygame.event.get()                
            bookPuzAAtoJJ()      
        pygame.display.update()
    FPSCLOCK.tick(FPS)        
                
def bookPuzAAtoJJ():
    while True:
        if random.randint(1, 10) == 1:
            bookPuzAA()
        if random.randint(1, 10) == 2:
            bookPuzBB()
        if random.randint(1, 10) == 3:
            bookPuzCC()
        if random.randint(1, 10) == 4:
            bookPuzDD()
        if random.randint(1, 10) == 5:
            bookPuzEE()
        if random.randint(1, 10) == 6:
            bookPuzFF()
        if random.randint(1, 10) == 7:
            bookPuzGG()
        if random.randint(1, 10) == 8:
            bookPuzHH()
        if random.randint(1, 10) == 9:
            bookPuzII()
        if random.randint(1, 10) == 10:
            bookPuzJJ()            
        
def tresCaveBB(): #book puzzles 
    caveFull_SURF=pygame.image.load('tresCaveful.png').convert()
    DISPLAYSURF.fill(BLACK)                 #    rect pos        rect size
    TEDTRAN_RECT = pygame.Rect(250, 190, 440, 100)  #x and y    / size x  size  y  teds  white   
    BOOKTRAN_RECT = pygame.Rect(710, 190, 20, 100)  #x and y    / size x  size  y  book     white   
    BOTTRAN_RECT = pygame.Rect(250, 315, 670, 220) #x and y   / size x  size  y  botom  green
      
    while True:
        global score
        global tres        
        pygame.draw.rect(DISPLAYSURF,WHITE, TEDTRAN_RECT)       ####  white rect under background  teds       
        pygame.draw.rect(DISPLAYSURF,WHITE, BOOKTRAN_RECT)      ####  white rect under background  book
        pygame.draw.rect(DISPLAYSURF,GREEN, BOTTRAN_RECT)       #### green rect under background  botom        
        DISPLAYSURF.blit(caveFull_SURF, (5, 5))
        DISPLAYSURF.blit(candle1A_SURF, (210, 220))        
        DISPLAYSURF.blit(ted2Front_SURF, (50, 280))
        pygame.display.update()        
        pygame.time.wait(100)        
             
        scoreSurf=BIGFONT.render('Score :  '+ str(score), True, RED) 
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH- 300, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        
        scoreSurf=BIGFONT.render('Treasure :  '+ str(tres), True, RED)
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH- 600, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"* One item in the cave is worth 60 points, *" ,True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)
        
        chest2Font=pygame.font.Font('freesansbold.ttf', 24)
        chest2Surf=chest2Font.render(
'*Find it and solve 3 puzzles.* ', True, YELLOW)
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)
        
        chest3Font=pygame.font.Font('freesansbold.ttf', 24)
        chest3Surf=chest3Font.render(
'*You have 60 seconds for each puzzle.*', True, YELLOW)  
        chest3Rect=chest3Surf.get_rect()
        chest3Rect.midtop=(WINDOWWIDTH/2, 790)
        DISPLAYSURF.blit(chest3Surf, chest3Rect)
        DISPLAYSURF.blit(candle1B_SURF, (210, 220))
        
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and BOOKTRAN_RECT.collidepoint(event. pos):
                puzMesC()
                pygame.display.update()                
                pygame.time.wait(3000)                 
                book()  #0k
                
            if event.type == MOUSEBUTTONUP and TEDTRAN_RECT.collidepoint(event. pos): #ok
                puzMesS()
                pygame.display.update()
                pygame.time.wait(3000)
                tresCaveBB()#ok
            if event.type == MOUSEBUTTONUP and BOTTRAN_RECT.collidepoint(event. pos): #ok
                puzMesS()
                pygame.display.update()
                pygame.time.wait(3000)
                tresCaveBB()  #ok              
            
        pygame.display.update()        
        pygame.time.wait(1000) 
        FPSCLOCK.tick(FPS)
        
def mouseRun(): ## walk / run away / & angles 
    mouseCave_SURF =pygame.image.load('mouseCaveBBla.png').convert()
    mouseimg=pygame.image.load('mice.png').convert()
    mousesObj.play()
    while True:
        FPS=30  
        width = 140  #start size
        height = 140
        
        mousex=600  # w   start position
        mousey=480  # h

        direction='up'
        while True:    
            if direction=='up':
                mousex -= 18 # +> angle to right / - < angle to left / del for strait
                mousey -= 10 # forward steps
                width -= 7  # size
                height -= 7 # size
                        
                DISPLAYSURF.fill(BLACK)
                DISPLAYSURF.blit(mouseCave_SURF, (5, 5))
                mouse = pygame.transform.scale(mouseimg, (width, height))
                
                DISPLAYSURF.blit(mouse, (mousex, mousey))            
                pygame.display.update()            
                pygame.time.wait(100) #500 for walk //100 for run
               
                if mousey <= 280:
                    pygame.time.wait(1000)
                    pygame.mixer.Sound.stop(mousesObj)                     
                    return# sent back to program                                         
    FPSCLOCK.tick(FPS)#ok
    
def tresMouseCaveBB():  #ok
    mouseRun()
    mouseCave =pygame.image.load('mouseCaveBBla.png').convert()
    TRAN2_RECT = pygame.Rect(830, 250, 30, 200) #x and y , size x  size  y
    while True:
        pygame.draw.rect(DISPLAYSURF,WHITE, TRAN2_RECT)#### white rect under background 
        DISPLAYSURF.blit(mouseCave, (5, 5))
        
        scoreSurf=BIGFONT.render('Score :  '+ str(score), True, RED) 
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH- 300, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        
        scoreSurf=BIGFONT.render('Treasure :  '+ str(tres), True, RED) 
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH- 600, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        
        mice2Font=pygame.font.Font('freesansbold.ttf', 24)
        mice2Surf=mice2Font.render(
'*There are a lot of mice in this tunnel .* ', True, YELLOW)
        mice2Rect=mice2Surf.get_rect()
        mice2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(mice2Surf, mice2Rect)
        
        mice3Font=pygame.font.Font('freesansbold.ttf', 24)
        mice3Surf=mice3Font.render(
'* You can play with one or press  , c , to continue.*', True, YELLOW)
        mice3Rect=mice3Surf.get_rect()
        mice3Rect.midtop=(WINDOWWIDTH/2, 790)
        DISPLAYSURF.blit(mice3Surf, mice3Rect)
        pygame.display.update()

        for event in pygame.event.get():
            if event.type == MOUSEBUTTONUP and TRAN2_RECT.collidepoint(event. pos):
                walkRun3()
            if event.type == KEYUP:
                if (event.key == K_c):
                    tresCaveBB()                          
        pygame.display.update()

def walkRun3(): ## walk / run away / & angles   ok
    global walk1img, walk2img, backDrop_SURF 
    walk1img=pygame.image.load('tedBackWalk1Small.png').convert()
    walk2img=pygame.image.load('tedBackWalk2Small.png').convert()    
    backDrop_SURF=pygame.image.load('mouseCaveBBla.png').convert()
    DISPLAYSURF.fill(BLACK)
        
    mice22Font=pygame.font.Font('freesansbold.ttf', 24)
    mice22Surf=mice22Font.render(
'* You have found a treasure cave .* ', True, YELLOW)
    mice22Rect=mice22Surf.get_rect()
    mice22Rect.midtop=(WINDOWWIDTH/2, 760)
    DISPLAYSURF.blit(mice22Surf, mice22Rect)
        
    mice33Font=pygame.font.Font('freesansbold.ttf', 24)
    mice33Surf=mice33Font.render(
'* Ted can test his luck.*', True, YELLOW) # to be changed
    mice33Rect=mice33Surf.get_rect()
    mice33Rect.midtop=(WINDOWWIDTH/2, 790)
    DISPLAYSURF.blit(mice33Surf, mice33Rect)
    pygame.display.update()

    while True:
        FPS=30  
        width = 160  ## size  of  ted
        height = 260
        
        walk1bx=570  # w start  positions
        walk1by=320 #  h
        walk2bx=570  # w 
        walk2by=310  # h  

        direction='up'
        while True:    
            if direction=='up':
                walk1bx += 15 # +> angle to right / - < angle to left / del for strait
                walk1by -= 2  # steps forward
                width -= 1   # size of ted   - smaller / + larger
                height -= 2   # size of ted
                        
                DISPLAYSURF.blit(blacka, (5, 5))
                DISPLAYSURF.blit(backDrop_SURF, (5, 5))
                ted = pygame.transform.scale(walk1img, (width, height))
                
                DISPLAYSURF.blit(ted, (walk1bx, walk1by))            
                pygame.display.update()            
                pygame.time.wait(300) ##500 for walk //100 for run
    
                walk2by = walk1by  #  steps forward
                walk2bx = walk1bx  # > / < angles
                
                walk1bx += 15 # +> angle to right / - < angle to left / del for strait
                walk2by -= 2  # steps forward              
                width -= 1   # size of ted
                height -= 2   # size
                              
                DISPLAYSURF.blit(blacka, (5, 5))
                DISPLAYSURF.blit(backDrop_SURF, (5, 5))
                ted2 = pygame.transform.scale(walk2img, (width, height))
                
                DISPLAYSURF.blit(ted2, (walk2bx, walk2by))       
                pygame.display.update()             
                pygame.time.wait(300)  # 500 for walk // 100 for run
                
                walk1by = walk2by  # steps forward
                walk1bx = walk2bx  # > / < angles
                
                if walk1by <= 270:  # end point
                    pygame.time.wait(1000)                
                    tresCaveBB()#return# sent back to program                 
                if walk2by <= 270:  # end point
                    pygame.time.wait(1000)                   
                    tresCaveBB()#return#  sent back  #  tresCave()                      
    FPSCLOCK.tick(FPS)

def candyAn2():##to tresMouseCave
    DISPLAYSURF.fill(BLACK)
    windObj.play()
    fallimg=candPapper_SURF
    fallx=900
    fally=300
    direction='left'
    while True:
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF, (900, 400))
        DISPLAYSURF.blit(lottie_SURF, (600,500))
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"**A draft from a tunnel blows the wraper**",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)        
        chest2Font=pygame.font.Font('freesansbold.ttf', 24)
        chest2Surf=chest2Font.render(
"** Ted's found another secret tunnel**.",True, YELLOW)
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)        
        pleaseWait()
        if direction=='left':
            fallx -= 5
            if fallx== 500:
                direction='down'#ok
                
        elif direction=='down':#ok
            fally+=3
            if fally==600: #ok     
                 pygame.time.wait(8000)
                 pygame.mixer.Sound.stop(windObj)
                 tresMouseCaveBB()           
        DISPLAYSURF.blit(fallimg, (fallx, fally))        
        pygame.display.update()     
        FPSCLOCK.tick(FPS)          
        
def toRailTun():#to railTunticket
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF, (900, 400))
        DISPLAYSURF.blit(lottie_SURF, (600,500))
        DISPLAYSURF.blit(candy_SURF, (500, 500))
        
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"** 3 doors are open. Ted can eat his candy**",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)        
        chest2Font=pygame.font.Font('freesansbold.ttf', 24)
        chest2Surf=chest2Font.render(
"**Ted throws the wraper to the cat for her to play with **.",True, YELLOW)
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 760)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)        
        startKeyMes()
        if keyPress():
            pygame.event.get()
            candyAn2()
        pygame.display.update()
def finalScoreA():#
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(trainEnd_SURF, (5, 5))
        DISPLAYSURF.blit(tedBackS_SURF, (650, 350))#       
                
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)
        chestFont=pygame.font.Font('freesansbold.ttf', 50)
        chestSurf=chestFont.render(
"* Your score was low , try again .*",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)        
        chest2Font=pygame.font.Font('freesansbold.ttf', 50)
        chest2Surf=chest2Font.render(
"** Top score is 180  points,  40  treasure  points   ***.",True, YELLOW)# top score  ???????????/
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 810)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)
        pygame.display.update()
        pygame.time.wait(14000)
        gameOver()
        FPSCLOCK.tick(FPS)
       
    
def finalScoreB():
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(trainEnd_SURF, (5, 5))
        DISPLAYSURF.blit(tedBackS_SURF, (650, 350))#       
        chestFont=pygame.font.Font('freesansbold.ttf', 50)
        chestSurf=chestFont.render(
"* Your score was average *",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)        
        chest2Font=pygame.font.Font('freesansbold.ttf', 50)
        chest2Surf=chest2Font.render(
"** Top score is  180  points,  40  treasure  points. ***.",True, YELLOW)#  top score ????????????
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 810)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)                
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)
        pygame.display.update()
        pygame.time.wait(14000)
        gameOver()
        FPSCLOCK.tick(FPS)

        
    
def finalScoreC():
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(trainEnd_SURF, (5, 5))
        DISPLAYSURF.blit(tedBackS_SURF, (650, 350))#       
                
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)
        chestFont=pygame.font.Font('freesansbold.ttf', 50)
        chestSurf=chestFont.render(
"*Well done you have a high score*",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)        
        chest2Font=pygame.font.Font('freesansbold.ttf', 50)
        chest2Surf=chest2Font.render(
"** Top score is  180  points  ,  40  treasure  points. ***.",True, YELLOW)##    top score  ????
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 810)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)

        pygame.display.update()
        pygame.time.wait(14000)
        gameOver()
        FPSCLOCK.tick(FPS)
    
def finalScore():
    global score
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(trainEnd_SURF, (5, 5))
        DISPLAYSURF.blit(tedBackS_SURF, (650, 350))#       
                
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)
        if score < 80:
            finalScoreA()
        if score > 80 and score < 160:
            finalScoreB()
        if score > 160:
            finalScoreC()       
        pygame.display.update()
        
def station():
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(trainEnd_SURF, (5, 5))
        DISPLAYSURF.blit(tedBackS_SURF, (650, 350))##ok
        
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)        
        chestFont=pygame.font.Font('freesansbold.ttf', 50)
        chestSurf=chestFont.render(
"**  THE  END  **",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(chestSurf, chestRect)        
        chest2Font=pygame.font.Font('freesansbold.ttf', 50)
        chest2Surf=chest2Font.render(
"** How was your score  **.",True, YELLOW)
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 810)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)
        pygame.display.update()        
        checkForQuit()
        pygame.time.wait(8000)
        finalScore()              

        FPSCLOCK.tick(FPS)          
        
def railwayHome():#ok
    while True:
        global score
        score += 10        
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(railTun_SURF, (5, 5))
        DISPLAYSURF.blit(railTicket_SURF, (550, 650))

        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"* .Ted runs along  the tacks to the station*",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 770)
        DISPLAYSURF.blit(chestSurf, chestRect)        
        chest2Font=pygame.font.Font('freesansbold.ttf', 24)
        chest2Surf=chest2Font.render(
"**and catches the next train home.   ***.",True, YELLOW)
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 810)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)
        
        pygame.display.update()        
        checkForQuit()
        pygame.time.wait(12000)
        station()              
        FPSCLOCK.tick(FPS)   
        
def railwayBackToStart():
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(railTun_SURF, (5, 5))
        DISPLAYSURF.blit(busTicket_SURF, (550, 650))

        chestFont=pygame.font.Font('freesansbold.ttf', 36)
        chestSurf=chestFont.render(
"* You have killed Ted*",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 770)
        DISPLAYSURF.blit(chestSurf, chestRect)        
        chest2Font=pygame.font.Font('freesansbold.ttf', 24)
        chest2Surf=chest2Font.render(
"*** Ted's not happy. ***.",True, YELLOW)
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 810)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)
        pygame.display.update()        
        checkForQuit()
        pygame.time.wait(12000) 
        gameOver()              

        FPSCLOCK.tick(FPS)

def caragePass():  ##left ot right
    trainObj.play()
    caragex=-100
    caragey=200
    pygame.time.wait(2000)
    
    direction='right'
    while True:    
        if direction=='right':    
            caragex += 15  # 
            
            DISPLAYSURF.blit(tunFill_SURF, (5, 10))               
            DISPLAYSURF.blit(carageimg, (caragex, caragey))
            DISPLAYSURF.blit(carageTun_SURF, (5, 10))                 
            pygame.display.update()            
            pygame.time.wait(50)                                             
            checkForQuit()
                               
            if caragex >= 1000:
                pygame.mixer.Sound.stop(trainObj)
                pygame.time.wait(3000)
                return                          
        
    FPSCLOCK.tick(FPS)
def trainPassB():##to  railwayBackToStart   from  railTunTicket  
    
    global carageimg 
    carageimg=pygame.image.load('carage.png')   
    
    carageTun_SURF=pygame.image.load('carage_tunnel.png').convert()
    
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(railTicket_SURF, (730, 650))        
        tunFont=pygame.font.Font('freesansbold.ttf', 24)
        tunSurf=tunFont.render(
"**At the end of this tunnel it meets a train tunnel ,Ted runs on to the tracks**",True, YELLOW)
        tunRect=tunSurf.get_rect()
        tunRect.midtop=(WINDOWWIDTH/2, 770)
        DISPLAYSURF.blit(tunSurf, tunRect)
        
        tun2Font=pygame.font.Font('freesansbold.ttf', 24)
        tun2Surf=tun2Font.render(
"**and is hit by a train **",True, YELLOW)
        tun2Rect=tun2Surf.get_rect()
        tun2Rect.midtop=(WINDOWWIDTH/2, 800)
        DISPLAYSURF.blit(tun2Surf, tun2Rect)         
        caragePass()
       
        pygame.display.update()
        pygame.time.wait(1000)
        railwayBackToStart()
        checkForQuit()
        
def trainPassR():##to railwayHome  ok
    global carageimg 
    carageimg=pygame.image.load('carage.png')   
    
    carageTun_SURF=pygame.image.load('carage_tunnel.png').convert()
    
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(railTicket_SURF, (730, 650))        
        tunFont=pygame.font.Font('freesansbold.ttf', 24)#ok
        tunSurf=tunFont.render(
"**At the end of this tunnel it meets a train tunnel**",True, YELLOW)
        tunRect=tunSurf.get_rect()
        tunRect.midtop=(WINDOWWIDTH/2, 770)
        DISPLAYSURF.blit(tunSurf, tunRect)
        
        tun2Font=pygame.font.Font('freesansbold.ttf', 24)##ok
        tun2Surf=tun2Font.render(
"**Ted can use his ticket **",True, YELLOW)
        tun2Rect=tun2Surf.get_rect()
        tun2Rect.midtop=(WINDOWWIDTH/2, 800)
        DISPLAYSURF.blit(tun2Surf, tun2Rect)         
        caragePass()
       
        pygame.display.update()
        pygame.time.wait(1000)
        railwayHome()
        checkForQuit()
            
    FPSCLOCK.tick(FPS)   

def railTunTicket():##ok// extra  line ????????????
    while True:
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(tunnel_SURF, (5, 5))
        DISPLAYSURF.blit(ted2Front_SURF, (900, 400))
        DISPLAYSURF.blit(lottie_SURF, (600,500))
        DISPLAYSURF.blit(B_R_ticket_SURF, (400, 550))
        DISPLAYSURF.blit(busTicket_SURF, (550, 650))
        DISPLAYSURF.blit(railTicket_SURF, (730, 650))
        chestFont=pygame.font.Font('freesansbold.ttf', 24)
        chestSurf=chestFont.render(
"**In the secret tunnel on the floor are 2 tickets you may only pick one **",True, YELLOW)
        chestRect=chestSurf.get_rect()
        chestRect.midtop=(WINDOWWIDTH/2, 770)
        DISPLAYSURF.blit(chestSurf, chestRect)        
        chest2Font=pygame.font.Font('freesansbold.ttf', 24)
        chest2Surf=chest2Font.render(
"**Press , b , for bus ticket  or,  r,  for rail ticket**  !! Choose Wisely !!.",True, YELLOW)
        chest2Rect=chest2Surf.get_rect()
        chest2Rect.midtop=(WINDOWWIDTH/2, 810)
        DISPLAYSURF.blit(chest2Surf, chest2Rect)
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_b):
                    trainPassB()
                if (event.key==K_r):
                    trainPassR()     

        pygame.display.update()         
        
        
def redTunnelxy():  ######from ted fall
    while True:    
        DISPLAYSURF.fill(BLACK)
        DISPLAYSURF.blit(redTunXY_SURF, (5, 5))
        DISPLAYSURF.blit(cBar_SURF, (350, 600))
        DISPLAYSURF.blit(candy_SURF, (530, 620))
        DISPLAYSURF.blit(key_SURF, (730, 620))
        DISPLAYSURF.blit(ted2Front_SURF,(200, 330))
                
        scoreSurf=BIGFONT.render('Score:' + str(score), True, RED)#ok
        scoreRect=scoreSurf.get_rect()
        scoreRect.topleft=(WINDOWWIDTH-500, 20)
        DISPLAYSURF.blit(scoreSurf, scoreRect)
        tresSurf=BIGFONT.render('Treasure:' + str(tres), True, RED)#ok
        tresRect=tresSurf.get_rect()
        tresRect.topleft=(WINDOWWIDTH-300, 20)
        DISPLAYSURF.blit(tresSurf, tresRect)
        
        caveBLFont=pygame.font.Font('freesansbold.ttf', 24)
        caveBLSurf=caveBLFont.render(
'In front of the red tunnels are 3 items, you may only pick one.',True, YELLOW)
        caveBLRect=caveBLSurf.get_rect()
        caveBLRect.midtop=(WINDOWWIDTH/2, 730)
        DISPLAYSURF.blit(caveBLSurf, caveBLRect)
        
        caveBL2Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL2Surf=caveBL2Font.render(
'Items, *  (a) Crowbar ,heavy.  * (b) Candy in wraper *  (c)  Key, small */  Press  a,  b,  or  c .',True, YELLOW)
        caveBL2Rect=caveBL2Surf.get_rect()
        caveBL2Rect.midtop=(WINDOWWIDTH/2, 755)
        DISPLAYSURF.blit(caveBL2Surf, caveBL2Rect)
        
        caveBL3Font=pygame.font.Font('freesansbold.ttf', 24)
        caveBL3Surf=caveBL3Font.render(
' Goal  *  Get Ted safely through the tunnels and find treasure points.',True, YELLOW)
        caveBL3Rect=caveBL3Surf.get_rect()
        caveBL3Rect.midtop=(WINDOWWIDTH/2, 780)
        DISPLAYSURF.blit(caveBL3Surf, caveBL3Rect)        
        for event in pygame.event.get():
            if event.type==KEYUP:
                if (event.key==K_a):##ok
                    cBar()
                if (event.key==K_b):##ok
                    candy()
                if (event.key==K_c):##0k
                    keyTunnelXY()
        pygame.display.update()        

                           

if __name__=='__main__': 
    main()

















    
    


    











    
